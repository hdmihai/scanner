#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
core.evidence
============
Transforma indicatorii bruti in EVIDENTE: fapte numite, cu directie si
intensitate, care pot fi si citite de om si folosite ca intrari de model.

DE CE ACEST STRAT
-----------------
Pana acum existau doua lumi separate: agentul invata din sase numere abstracte
(trend, momentum, volatility, volume), iar dashboard-ul afisa indicatori pe
care agentul nu-i vedea niciodata. Nimic nu lega ce invata de ce arata.

Aici ele devin acelasi obiect. O evidenta are eticheta in limbaj natural
("EMA 9 este peste EMA 20"), o directie (LONG / SHORT / NEUTRU) si o
intensitate 0..1. Lista completa se salveaza pe plan: dashboard-ul o afiseaza
ca atare, iar agentul o consuma ca vector de caracteristici.

ORIENTAREA DUPA DIRECTIE - detaliul care conteaza
-------------------------------------------------
Caracteristicile se orienteaza dupa directia planului: o evidenta care sustine
directia da +1, una care o contrazice da -1, indiferent daca planul e LONG sau
SHORT. Fara asta, modelul invata reguli separate pentru fiecare directie si
imparte datele in doua. Masurat pe proiectul asta: greutatea `is_long` ajunsese
-1.93, dominand tot restul - modelul memorase "shorturile castiga", ceea ce era
regimul de piata din acea fereastra, nu o relatie reala.

CE NU E AICI, SI DE CE
----------------------
Order flow si footprint delta din sistemul de referinta cer date de tick sau
order book istoric. OKX nu ofera order book istoric, deci nu pot fi calculate
in backtest - iar o evidenta care exista doar live si lipseste in backtest ar
face cele doua incomparabile. Prefer sa lipseasca din amandoua.
"""

# Ce capabilitate cere fiecare evidenta. Cele care nu apar aici au nevoie doar
# de OHLCV, deci merg peste tot. Evidentele fara suport pe bursa curenta sunt
# OMISE - nu inlocuite cu zero, care ar insemna "evidenta neutra" si ar minti
# modelul despre ce a vazut.
REQUIRES = {"order_flow": "trades_live", "book_imbalance": "orderbook_live"}
# `liq_magnet` NU apare aici: harta de lichidari se construieste din OHLCV, deci
# exista si in backtest. Asta e diferenta fata de order flow - si motivul pentru
# care poate intra in invatare fara sa fragmenteze datele.


DIR_LONG = "LONG"
DIR_SHORT = "SHORT"
DIR_NEUTRAL = "NEUTRU"


def _clip(v, lo=-1.0, hi=1.0):
    return max(lo, min(hi, v))


def _item(key, label, direction, strength, value=None):
    return {"key": key, "label": label, "direction": direction,
            "strength": round(max(0.0, min(1.0, strength)), 4),
            "value": value}


def build_evidence(ind, price, atr, rsi=None, components=None,
                   flow=None, book=None, caps=None, liq=None, liq_bias=None,
                   struct=None, ew=None, ew_bias=None,
                   liqs=None, liqs_bias=None, alt=None, symbol=None, direction=None, rel=None):
    """Construieste lista de evidente dintr-un set de indicatori.

    `ind` e iesirea lui indicators.compute_all(). Orice lipseste se sare -
    pe simboluri cu istoric scurt unii indicatori nu se pot calcula, si e mai
    bine sa aiba mai putine evidente decat sa inventez valori.
    """
    ev = []
    if not ind or not price or price <= 0:
        return ev
    atr = atr or (price * 0.01)

    emas = ind.get("emas") or {}
    e9, e20, e50 = emas.get("ema9"), emas.get("ema20"), emas.get("ema50")
    e100, e200 = emas.get("ema100"), emas.get("ema200")

    if e9 and e20:
        up = e9 > e20
        gap = abs(e9 - e20) / atr
        ev.append(_item("ema_fast", f"EMA 9 este {'peste' if up else 'sub'} EMA 20",
                        DIR_LONG if up else DIR_SHORT, _clip(gap / 2, 0, 1), round(gap, 3)))

    stack = [x for x in (e20, e50, e100, e200) if x]
    if len(stack) >= 3:
        asc = sum(1 for a, b in zip(stack, stack[1:]) if a > b)
        desc = sum(1 for a, b in zip(stack, stack[1:]) if a < b)
        total = len(stack) - 1
        if asc > desc:
            ev.append(_item("ema_stack", "Structura EMA medie/lunga e ascendenta",
                            DIR_LONG, asc / total, f"{asc}/{total}"))
        elif desc > asc:
            ev.append(_item("ema_stack", "Structura EMA medie/lunga e descendenta",
                            DIR_SHORT, desc / total, f"{desc}/{total}"))

    st = ind.get("supertrend") or {}
    if st.get("direction"):
        bull = st["direction"] == "BULLISH"
        dist = abs(price - (st.get("level") or price)) / atr
        ev.append(_item("supertrend", f"SuperTrend confirma structura "
                                      f"{'ascendenta' if bull else 'descendenta'}",
                        DIR_LONG if bull else DIR_SHORT, _clip(dist / 3, 0, 1),
                        st.get("level")))

    macd = ind.get("macd") or {}
    if macd.get("histogram") is not None:
        h = macd["histogram"]
        ev.append(_item("macd", f"Histograma MACD e {'pozitiva' if h > 0 else 'negativa'}",
                        DIR_LONG if h > 0 else DIR_SHORT,
                        _clip(abs(h) / (atr * 0.5), 0, 1), round(h, 8)))

    vwap = ind.get("vwap")
    if vwap:
        above = price > vwap
        d = abs(price - vwap) / atr
        ev.append(_item("vwap", f"Pretul e {'peste' if above else 'sub'} VWAP",
                        DIR_LONG if above else DIR_SHORT, _clip(d / 2, 0, 1), round(vwap, 8)))

    vp = ind.get("volume_profile") or {}
    if vp.get("poc"):
        above = price > vp["poc"]
        d = abs(price - vp["poc"]) / atr
        ev.append(_item("poc", f"Pretul e {'peste' if above else 'sub'} POC",
                        DIR_LONG if above else DIR_SHORT, _clip(d / 3, 0, 1), vp["poc"]))
    pos = ind.get("price_vs_value_area")
    if pos == "PESTE VAH":
        ev.append(_item("value_area", "Pretul e acceptat peste value area", DIR_LONG, 0.7, pos))
    elif pos == "SUB VAL":
        ev.append(_item("value_area", "Pretul e acceptat sub value area", DIR_SHORT, 0.7, pos))
    elif pos:
        ev.append(_item("value_area", "Pretul e in interiorul value area", DIR_NEUTRAL, 0.3, pos))

    if rsi is not None:
        if rsi >= 70:
            ev.append(_item("rsi", f"RSI supracumparat ({rsi:.0f})", DIR_SHORT,
                            _clip((rsi - 70) / 20, 0, 1), round(rsi, 1)))
        elif rsi <= 30:
            ev.append(_item("rsi", f"RSI supravandut ({rsi:.0f})", DIR_LONG,
                            _clip((30 - rsi) / 20, 0, 1), round(rsi, 1)))
        else:
            up = rsi > 50
            ev.append(_item("rsi", f"RSI in zona neutra, inclinat {'in sus' if up else 'in jos'} ({rsi:.0f})",
                            DIR_LONG if up else DIR_SHORT, abs(rsi - 50) / 20, round(rsi, 1)))

    caps = set(caps or [])

    # ORDER FLOW - cere trades_live. Echivalentul "order flow favors sellers
    # (78.2% sell)" din sistemul de referinta. Exista doar live: arhivele
    # istorice de tranzactii sunt de ordinul zecilor de mii de GB pentru
    # universul nostru, deci backtest-ul ruleaza fara evidenta asta, iar
    # semnatura de capabilitati tine cele doua seturi separate la invatare.
    if flow and REQUIRES["order_flow"] in caps:
        sell_pct = flow.get("sell_pct")
        if sell_pct is not None:
            sellers = sell_pct > 50
            ev.append(_item("order_flow",
                            f"Fluxul recent favorizeaza {'vanzatorii' if sellers else 'cumparatorii'} "
                            f"({max(sell_pct, 100 - sell_pct):.1f}%)",
                            DIR_SHORT if sellers else DIR_LONG,
                            _clip(abs(sell_pct - 50) / 30, 0, 1), sell_pct))

    # DEZECHILIBRU DE CARTE - cere orderbook_live.
    if book and REQUIRES["book_imbalance"] in caps:
        b, a = book.get("bid_volume"), book.get("ask_volume")
        if b and a and (b + a) > 0:
            bid_pct = 100 * b / (b + a)
            heavy_bid = bid_pct > 50
            ev.append(_item("book_imbalance",
                            f"Cartea de ordine e mai grea pe {'cumparare' if heavy_bid else 'vanzare'} "
                            f"({max(bid_pct, 100 - bid_pct):.1f}%)",
                            DIR_LONG if heavy_bid else DIR_SHORT,
                            _clip(abs(bid_pct - 50) / 25, 0, 1), round(bid_pct, 1)))

    # MAGNET DE LICHIDARE. Clusterele dense atrag pretul: lichidarile fortate
    # genereaza ordine in acea directie. Deasupra pretului sunt lichidari de
    # SHORT (magnet in sus), dedesubt de LONG (magnet in jos).
    if liq and liq_bias is not None:
        above, below = liq.get("above"), liq.get("below")
        target = above if liq_bias > 0 else below
        if target:
            up = target["price"] > price
            ev.append(_item("liq_magnet",
                            f"Cluster de lichidari {'SHORT' if up else 'LONG'} la "
                            f"{abs(target['distance_pct']):.1f}% "
                            f"{'peste' if up else 'sub'} pret",
                            DIR_LONG if up else DIR_SHORT,
                            _clip(abs(liq_bias), 0, 1),
                            round(target["price"], 8)))

    # STRUCTURA DE PIATA. `mtf_align` e singura de aici care aduce informatie
    # INDEPENDENTA: celelalte evidente sunt toate transformari ale aceleiasi
    # serii de lumanari, deci se suprapun. Un trend pe alt timeframe nu e.
    if struct:
        ich = struct.get("ichimoku")
        if ich and ich.get("vote"):
            ev.append(_item("ichimoku", f"Pretul e {ich['position']} Ichimoku",
                            DIR_LONG if ich["vote"] > 0 else DIR_SHORT,
                            _clip(ich.get("strength", 0.5), 0, 1),
                            round(ich.get("kijun") or 0, 8)))
        cr = struct.get("cross")
        if cr:
            ev.append(_item("ma_cross", cr["type"],
                            DIR_LONG if cr["bullish"] else DIR_SHORT,
                            _clip(cr.get("strength", 0.5), 0, 1),
                            round(cr.get("fast") or 0, 8)))
        rg = struct.get("regime")
        if rg and rg.get("vote"):
            ev.append(_item("regime", f"{rg['label']} (putere {rg['strength']})",
                            DIR_LONG if rg["vote"] > 0 else DIR_SHORT,
                            _clip(abs(rg["vote"]) * rg["strength"] / 100.0, 0, 1),
                            rg["strength"]))
        # aceeasi definitie live si in backtest: baza + timeframe-uri mai mari
        mtf = struct.get("mtf") or {}
        a = mtf.get("alignment_htf") if "alignment_htf" in mtf else mtf.get("alignment")
        cnt = mtf.get("counted_htf") if "alignment_htf" in mtf else mtf.get("counted")
        if a is not None and cnt:
            bu = mtf.get("bullish_htf", mtf.get("bullish"))
            be = mtf.get("bearish_htf", mtf.get("bearish"))
            ev.append(_item("mtf_align",
                            f"Aliniere multi-timeframe: {bu} sus / {be} jos din {cnt}",
                            DIR_LONG if a > 0 else (DIR_SHORT if a < 0 else DIR_NEUTRAL),
                            _clip(abs(a), 0, 1), round(a, 3)))

    # ELLIOTT. Folosesc doar ipotezele INCA VALIDE - o numaratoare invalidata
    # de pret nu are voie sa contribuie, oricat de mare i-ar fi fost increderea.
    # `ew_bias` e deja calculat pe ele.
    if ew and ew_bias is not None:
        pr = ew.get("primary")
        if pr:
            ev.append(_item("elliott",
                            f"{pr['pattern']} {pr['direction']} "
                            f"({pr['confidence']*100:.0f}%, {ew.get('alive',0)} din "
                            f"{ew.get('total',0)} valide)",
                            DIR_LONG if ew_bias > 0 else (DIR_SHORT if ew_bias < 0 else DIR_NEUTRAL),
                            _clip(abs(ew_bias), 0, 1),
                            round(pr.get("invalidation") or 0, 8)))

    # LICHIDITATE STRUCTURALA. Pretul e atras spre bazinele NEATINSE de stopuri;
    # cele deja maturate nu mai trag, fiindca lichiditatea s-a consumat.
    if liqs and liqs_bias is not None:
        tgt = liqs.get("above") if liqs_bias > 0 else liqs.get("below")
        if tgt:
            ev.append(_item("liq_struct",
                            f"{tgt['kind']} la {abs(tgt['distance_pct']):.1f}% "
                            f"({tgt['role']}, {tgt['touches']} atingeri)",
                            DIR_LONG if tgt["side"] == "BUY" else DIR_SHORT,
                            _clip(abs(liqs_bias), 0, 1), round(tgt["price"], 8)))
        # SWEEP-UL PE O SINGURA PARTE e semnalul SMC urmarit de metoda: lichiditatea
        # de sub minime luata si pretul revenit deasupra -> intoarcere in sus (LONG);
        # simetric pentru maxime (SHORT). Inainte se emitea doar sweep-ul bilateral,
        # neutru - caracteristica era 0 in 100% din planuri, iar agentul nu o vedea.
        if liqs.get("two_sided_sweep"):
            ev.append(_item("liq_sweep",
                            "Sweep bilateral - lichiditate luata sus SI jos",
                            DIR_NEUTRAL, 0.5, 1))
        elif liqs.get("swept_sell"):
            ev.append(_item("liq_sweep",
                            "Sweep sell-side: lichiditatea de sub minime a fost luata, pretul a revenit deasupra",
                            DIR_LONG, 0.6, 1))
        elif liqs.get("swept_buy"):
            ev.append(_item("liq_sweep",
                            "Sweep buy-side: lichiditatea de peste maxime a fost luata, pretul a revenit dedesubt",
                            DIR_SHORT, 0.6, 1))

    # FAZA ALTCOIN SEASON: context de piata, acelasi pentru toate simbolurile
    # la un moment dat, dar cu sens diferit: o faza care favorizeaza altcoins
    # sustine un LONG pe un altcoin si contrazice un SHORT; pentru BTC conteaza
    # cat favorizeaza faza bitcoin. Ponderat deja cu increderea clasificarii.
    if alt and (alt.get("classification") or {}).get("phase") is not None and direction:
        is_btc = (symbol or "").upper().startswith("BTC/")
        b = alt.get("btc_bias" if is_btc else "alt_bias") or 0.0
        cls = alt["classification"]
        if abs(b) >= 0.05:
            favors = (b > 0) == (direction == "LONG")
            ev.append(_item("altseason",
                            f"Faza {cls['phase']} - {cls['name']}: "
                            f"{'favorizeaza' if b > 0 else 'defavorizeaza'} LONG pe "
                            f"{'BTC' if is_btc else 'altcoins'}",
                            direction if favors else ("SHORT" if direction == "LONG" else "LONG"),
                            _clip(abs(b), 0, 1), cls["phase"]))

    # VERDICTUL ANALISTULUI WEB3 PE TOKEN (core/relative.verdict): forta relativa fata de BTC
    # pe 7/30 de zile si pozitia fata de MA200 1D, din inchideri zilnice - acelasi calcul ca pe
    # cardul analistului si in backtest. Bullish sustine LONG, Bearish sustine SHORT, Neutru nu
    # sustine nimic. Pentru BTC nu exista (forta relativa a BTC fata de el insusi e zero).
    # NU intra in `fusion` (EXCLUDED_FROM_FUSION): scorul de fuziune e o caracteristica a
    # agentului, invatata pe planuri fara aceasta evidenta - adaugata acolo, ar muta ev_fusion
    # live fara ca modelul sa fi vazut vreodata asa ceva. Agentul ii invata greutatea separat,
    # ca ev_analyst, abia cand backtest-ul o contine (core/agent.backtest_pending).
    if rel and rel.get("sentiment") and direction and not (symbol or "").upper().startswith("BTC/"):
        sent = rel["sentiment"]
        r7 = rel.get("rs7")
        txt = (f"Analist: {sent} - {'peste' if rel.get('above_ma200') else 'sub'} MA200 1D, "
               f"{rel['rs30']:+.1f}% vs BTC/30z" + ("" if r7 is None else f", {r7:+.1f}%/7z"))
        if sent == "Bullish":
            ev.append(_item("analyst", txt, DIR_LONG, 1.0, round(rel["rs30"], 2)))
        elif sent == "Bearish":
            ev.append(_item("analyst", txt, DIR_SHORT, 1.0, round(rel["rs30"], 2)))
        else:
            ev.append(_item("analyst", txt, DIR_NEUTRAL, 0.0, round(rel["rs30"], 2)))

    comp = components or {}
    if comp.get("volume") is not None:
        v = comp["volume"]
        ev.append(_item("volume", f"Volumul e {'peste' if v > 0.5 else 'sub'} media recenta",
                        DIR_NEUTRAL, abs(v - 0.5) * 2, round(v, 3)))
    if comp.get("volatility") is not None:
        ev.append(_item("volatility", "Volatilitatea e in intervalul favorabil"
                        if comp["volatility"] > 0.5 else "Volatilitatea e in afara intervalului favorabil",
                        DIR_NEUTRAL, abs(comp["volatility"] - 0.5) * 2, round(comp["volatility"], 3)))
    return ev


# Evidente afisate si invatate separat de agent, dar care nu intra in scorul de fuziune
# (vezi nota de la evidenta `analyst` din build_evidence).
EXCLUDED_FROM_FUSION = {"analyst"}


def fusion(evidence, direction):
    """Numara evidentele care sustin si care contrazic directia planului.
    Echivalentul panoului 'EVIDENCE FUSION' din sistemul de referinta, dar cu
    numere care chiar provin din ce s-a calculat."""
    evidence = [e for e in evidence if e.get("key") not in EXCLUDED_FROM_FUSION]
    support = [e for e in evidence if e["direction"] == direction]
    oppose = [e for e in evidence if e["direction"] not in (direction, DIR_NEUTRAL)]
    neutral = [e for e in evidence if e["direction"] == DIR_NEUTRAL]
    s = sum(e["strength"] for e in support)
    o = sum(e["strength"] for e in oppose)
    total = s + o
    return {
        "support": len(support), "oppose": len(oppose), "neutral": len(neutral),
        "support_weight": round(s, 3), "oppose_weight": round(o, 3),
        "score": round(100 * s / total, 1) if total > 0 else None,
    }


# Ordinea e fixa: vectorul de caracteristici trebuie sa aiba mereu aceeasi
# forma, altfel greutatile invatate nu mai corespund aceleiasi evidente.
EVIDENCE_KEYS = ["ema_fast", "ema_stack", "supertrend", "macd", "vwap",
                 "poc", "value_area", "rsi", "volume", "volatility",
                 "order_flow", "book_imbalance", "liq_magnet",
                 "ichimoku", "ma_cross", "regime", "mtf_align", "elliott",
                 "liq_struct", "liq_sweep", "altseason", "analyst"]


def evidence_features(evidence, direction):
    """Vector numeric pentru model, ORIENTAT dupa directia planului.

    +strength daca evidenta sustine directia, -strength daca o contrazice,
    0 daca e neutra sau lipseste. Asa modelul invata "evidenta aliniata ajuta",
    nu reguli separate pentru LONG si SHORT.
    """
    by_key = {e["key"]: e for e in evidence}
    feats = {}
    for k in EVIDENCE_KEYS:
        e = by_key.get(k)
        if not e:
            feats[f"ev_{k}"] = 0.0
        elif e["direction"] == direction:
            feats[f"ev_{k}"] = e["strength"]
        elif e["direction"] == DIR_NEUTRAL:
            feats[f"ev_{k}"] = 0.0
        else:
            feats[f"ev_{k}"] = -e["strength"]
    f = fusion(evidence, direction)
    feats["ev_fusion"] = ((f["score"] or 50.0) - 50.0) / 50.0
    return feats


FEATURE_KEYS = [f"ev_{k}" for k in EVIDENCE_KEYS] + ["ev_fusion"]
