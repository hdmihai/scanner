#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
backtest.py
============
Reia istoricul bara cu bara si genereaza planuri inchise cu R real, ca sa nu
mai astepti saptamani ca agentul sa adune date.

DE CE E ASTA CEL MAI IMPORTANT PAS
----------------------------------
Agentul are nevoie de 300 de planuri inchise SI de 21 de zile calendaristice
ca sa devina ACTIVE. Pragul de zile exista pentru ca datele stranse intr-o
fereastra scurta memoreaza un singur regim de piata - am vazut concret asta:
634 de exemple din 41 de ore aratau 76% acuratete, dar era doar "piata a
scazut, shorturile au castigat".

Backtest-ul satisface pragul LEGITIM, nu il ocoleste: 6 luni de lumanari
istorice contin efectiv 6 luni calendaristice, cu cresteri, scaderi si lateral.

DOUA REGULI DE CORECTITUDINE
----------------------------
1. FARA LOOK-AHEAD. La bara i, folosesc strict candles[:i+1]. Niciun calcul nu
   vede vreodata viitorul. Asta e greseala care face backtest-urile sa arate
   spectaculos si sa esueze in realitate.
2. ACELEASI FUNCTII CA LIVE. Import score_symbol, compute_trade_plan si
   evaluate_plan din modulele reale. Daca as rescrie logica aici, as testa alt
   cod decat cel care ruleaza - iar rezultatele n-ar insemna nimic.

CE NU MODELEAZA (limite oneste)
-------------------------------
- fara slippage si fara comisioane: R-ul real ar fi ceva mai mic
- fara order book, deci fara nivelurile de lichiditate
- presupune ca poti intra exact la pretul de inchidere al barei de semnal
- supravietuire: lista de simboluri e cea de azi, nu cea de acum 6 luni
- in live se deschid planuri doar pentru top 5 long + top 5 short dintr-o
  scanare; aici se deschide pentru orice semnal valid. Cu o watchlist de 7
  simboluri diferenta e neglijabila (aproape tot ar intra oricum in top 5),
  dar pe un univers de 200 backtest-ul ar fi mai permisiv decat realitatea.

RULARE
------
    python3 backtest.py                  # 180 de zile, watchlist-ul din CONFIG
    python3 backtest.py --days 90
    python3 backtest.py --sweep          # compara variante de intrare pe aceleasi date
    python3 backtest.py --walk-forward   # validare pe ferestre nevazute (recomandat)
    python3 backtest.py --walk-forward --rolling --windows 8
    python3 backtest.py --merge          # adauga rezultatele in data/plans.json
                                         # ca agentul sa invete din ele
"""

import json
import math
import os
import sys
import time

import ccxt

import crypto_ai_scanner as scanner
import evidence as ev_mod
import liquidation as liq_mod
import market_structure as struct_mod
import elliott as ew_mod
import liquidity_structure as ls_mod
import data_reset
import plan_tracker
from core import relative as rel_mod

DATA_DIR = "data"
BACKTEST_FILE = os.path.join(DATA_DIR, "backtest_plans.json")
PLANS_FILE = os.path.join(DATA_DIR, "plans.json")

DEFAULT_DAYS = 180
WARMUP_BARS = 200      # cate bare are nevoie score_symbol ca sa fie valid


def save_json(path, data, compact=False):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    # SCRIERE ATOMICA: fisier temporar, golit pe disc, apoi inlocuire intr-un singur
    # pas. Un job oprit in timpul scrierii (timeout, anulare) lasa intact fisierul
    # vechi - pasul de commit din workflow ruleaza cu if: always() si ar fi urcat
    # un JSON trunchiat, oprind toate scanarile urmatoare.
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        if compact:
            # Fisierele cu zeci de mii de planuri: `indent=2` aproape dubleaza
            # dimensiunea fara niciun castig.
            f.write(json.dumps(data, separators=(",", ":")))
        else:
            json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path) as f:
        return json.load(f)


# ========================== DESCARCARE ISTORIC ==============================

def find_listing_ts(exchange, symbol, timeframe, max_days, probes=14):
    """Cauta binar momentul in care simbolul a INCEPUT sa aiba date.

    DE CE E NEVOIE
    --------------
    Bursele nu returneaza "ce au" cand `since` e anterior listarii perechii -
    returneaza GOL. Varianta anterioara trata golul cerand fara `since`, ceea ce
    da cele mai RECENTE bare, nu cele mai vechi; apoi paginarea pornea din
    prezent si se oprea imediat. Masurat in productie: la 3650 de zile cerute,
    toate cele 28 de simboluri au primit 50 de zile, desi la 1825 primeau
    istoric complet. A cere mai mult returna mai putin.

    Cautarea binara gaseste cea mai veche data pentru care bursa raspunde cu
    date, deci fiecare simbol da exact cat exista: cele vechi dau ani, cele
    listate recent dau de la listare. Asta e "durata de viata" reala.

    Costa ~14 apeluri per simbol, o data - neglijabil fata de sutele de pagini
    de descarcare care urmeaza.
    """
    now = exchange.milliseconds()
    oldest = now - max_days * 86400 * 1000

    def has_data(ts):
        try:
            b = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=ts, limit=5)
            return bool(b)
        except Exception:
            return False

    # Daca cea mai veche data ceruta raspunde, nu mai caut: luam tot.
    if has_data(oldest):
        return oldest

    # Capatul "cu date" trebuie sa fie suficient de aproape de prezent ca sa
    # prinda si simbolurile listate foarte recent. Sondez mai multe distante:
    # un singur prag de 30 de zile rata tokenii de 20 de zile, care exista si
    # au date perfect utilizabile.
    probe_recent = None
    for d in (30, 7, 2, 1):
        cand = now - d * 86400 * 1000
        if has_data(cand):
            probe_recent = cand
            break
    if probe_recent is None:
        return None

    lo, hi = oldest, probe_recent      # lo=fara date, hi=cu date
    for _ in range(probes):
        mid = (lo + hi) // 2
        if hi - lo < 86400 * 1000:     # sub o zi diferenta: suficient de precis
            break
        if has_data(mid):
            hi = mid
        else:
            lo = mid
    return hi


def fetch_history(exchange, symbol, timeframe, days):
    """Descarca istoricul paginat, pornind de la momentul REAL al listarii.

    Un apel ccxt intoarce cel mult ~100-1500 de lumanari, deci paginez cu
    `since`. Punctul de start vine din find_listing_ts, nu din `now - days`:
    altfel simbolurile listate recent primesc gol si cad pe o rezerva care
    intoarce doar barele recente.
    """
    ms_per_bar = exchange.parse_timeframe(timeframe) * 1000
    since = find_listing_ts(exchange, symbol, timeframe, days)
    if since is None:
        print(f"  [!] {symbol}: bursa nu raspunde cu date pe {timeframe}.")
        return []

    requested = exchange.milliseconds() - days * 86400 * 1000
    if since > requested + 86400 * 1000:
        age_days = (exchange.milliseconds() - since) / 86400 / 1000
        print(f"  (listat acum ~{age_days:.0f} zile) ", end="")

    out = []
    stall = 0
    while True:
        try:
            batch = exchange.fetch_ohlcv(symbol, timeframe=timeframe,
                                         since=since, limit=1000)
        except Exception as e:
            print(f"  [!] {symbol}: {e}")
            break
        if not batch:
            break
        out.extend(batch)
        if len(batch) < 2:
            break
        next_since = batch[-1][0] + ms_per_bar
        if next_since <= since:
            stall += 1
            if stall > 2:
                break
            next_since = since + ms_per_bar * len(batch)
        else:
            stall = 0
        since = next_since
        if batch[-1][0] >= exchange.milliseconds() - ms_per_bar:
            break
        # FARA sleep manual: ccxt are enableRateLimit=True implicit si asteapta
        # deja `rateLimit` ms. Sleep-ul de aici se adauga peste, deci plateam
        # intarzierea de doua ori - masurat, 216 ms/pagina in loc de 110.
        if not getattr(exchange, "enableRateLimit", False):
            time.sleep(exchange.rateLimit / 1000)

    seen = {}
    for c in out:
        seen[c[0]] = c
    return [seen[k] for k in sorted(seen)]


def resolve_symbols(exchange, markets, tickers):
    """Traduce watchlist-ul in perechi reale de pe bursa, tinand cont de aliasuri."""
    watchlist = scanner.CONFIG.get("watchlist") or []
    if not watchlist:
        print("[!] CONFIG['watchlist'] e goala - backtest-ul are nevoie de o lista explicita.")
        return {}

    resolved = {}
    for base in watchlist:
        candidates = scanner.CONFIG.get("aliases", {}).get(base, [base])
        # Pentru BACKTEST conteaza ADANCIMEA istoricului, nu volumul de azi.
        # Rularea pe 5 ani a aratat de ce: POL/USDT a dat 12 zile pe OKX, desi
        # MATIC/USDT (acelasi proiect, denumirea veche) are ani intregi. Alegerea
        # dupa volum prefera tickerul nou, care abia a fost listat. Sondez cate
        # bare exista pentru fiecare alias si il iau pe cel mai adanc.
        # -inf, nu -1: `depth` e un timestamp negat, deci mereu foarte negativ.
        # Cu -1 ca valoare initiala niciun candidat nu ar fi trecut vreodata.
        best, best_depth = None, float("-inf")
        for alias in candidates:
            for quote in scanner.CONFIG["quotes"]:
                sym = f"{alias}/{quote}"
                if sym not in markets or not markets[sym].get("active", True):
                    continue
                try:
                    probe = exchange.fetch_ohlcv(sym, timeframe=scanner.CONFIG["timeframe"],
                                                 since=0, limit=1)
                    depth = -probe[0][0] if probe else 0   # cu cat mai vechi, cu atat mai bine
                except Exception:
                    depth = 0
                if depth > best_depth:
                    best, best_depth = sym, depth
        if best:
            resolved[base] = best
        else:
            print(f"  [!] {base}: nicio pereche gasita (aliasuri incercate: {candidates})")
    return resolved


# ============================== REPLAY ======================================

# ---------------------------------------------------------------------------
# PARITATE LIVE-BACKTEST pentru evidente (decalajul antrenare-utilizare).
# Masurat in productie: mtf_align si altseason erau nenule in 93-100% din
# planurile live si in 0% din cele de backtest - modelul invata pe date fara
# aceste semnale, apoi decidea live pe date cu ele.

DAY_MS = 86400000
WEEK_MS = 7 * DAY_MS
MONDAY_OFFSET = 4 * DAY_MS          # 1970-01-01 a fost joi; saptamanile incep luni


def htf_closes_index(candles, bar_ms):
    """Inchiderile ZILNICE si SAPTAMANALE complete, construite incremental din
    lumanarile de baza, plus cate erau complete la fiecare bara. La bara i se
    folosesc doar perioadele inchise pana la inchiderea ei - fara privire in
    viitor, exact ca live, unde ultima lumanare (neinchisa) e eliminata."""
    out = {}
    for name, span, off in (("1d", DAY_MS, 0), ("1w", WEEK_MS, MONDAY_OFFSET)):
        closes, counts, cur, done, prev = [], [], None, False, None
        for c in candles:
            k = (c[0] - off) // span
            if cur is not None and k != cur and not done and prev is not None:
                closes.append(prev)        # lipsa ultimei lumanari din perioada
            if k != cur:
                cur, done = k, False
            if (c[0] + bar_ms - off) % span == 0:
                closes.append(c[4])        # perioada s-a inchis odata cu aceasta bara
                done = True
            prev = c[4]
            counts.append(len(closes))
        out[name] = (closes, counts)
    return out


def bt_fetch_closes(base_closes, htf, i, base_tf, limit=119):
    """Echivalentul `_confirm_closes` din scaner pentru backtest: baza din fereastra,
    1d/1w din agregarea completa; timeframe-urile mai mici decat baza nu se pot
    reconstrui si sunt OMISE (exact ca un timeframe care nu raspunde live)."""
    def f(tf):
        if tf == base_tf:
            return base_closes
        if tf in htf:
            closes, counts = htf[tf]
            got = closes[:counts[i]][-limit:]
            return got if len(got) >= 60 else None
        return None
    return f


_ALT_DAYS = None


def alt_for_bar(open_ms, bar_ms):
    """Faza altseason a ULTIMEI zile complete la inchiderea barei, din istoricul pe
    10 ani (altseason_cycles.json) - aceeasi forma ca starea live."""
    global _ALT_DAYS
    if _ALT_DAYS is None:
        _ALT_DAYS = {}
        st = load_json(os.path.join(DATA_DIR, "altseason_cycles.json"), {}) or {}
        keys = st.get("timeline_keys") or []
        if "day" in keys and "phase" in keys:
            di, pi, ci = keys.index("day"), keys.index("phase"), keys.index("conf")
            for r in st.get("timeline") or []:
                _ALT_DAYS[r[di]] = (r[pi], r[ci])
    if not _ALT_DAYS:
        return None
    import altseason as _A
    day = time.strftime("%Y-%m-%d", time.gmtime((open_ms + bar_ms) / 1000.0 - 86400))
    hit = _ALT_DAYS.get(day)
    if not hit:
        return None
    ph, conf = hit
    return {"classification": {"phase": ph, "name": _A.PHASES[ph][1]},
            "alt_bias": round(_A.ALT_BIAS[ph] * conf, 3), "btc_bias": round(_A.BTC_BIAS[ph] * conf, 3)}


_BTC_DAYS = None


def btc_closes_until(day, n=201):
    """Inchiderile zilnice BTC (istoricul pe 10 ani, altseason_cycles.json) ale ultimelor `n`
    zile pana la `day` inclusiv - referinta fortei relative din evidenta `analyst`."""
    global _BTC_DAYS
    if _BTC_DAYS is None:
        _BTC_DAYS = ([], {})
        st = load_json(os.path.join(DATA_DIR, "altseason_cycles.json"), {}) or {}
        keys = st.get("timeline_keys") or []
        if "day" in keys and "btc" in keys:
            di, bi = keys.index("day"), keys.index("btc")
            for r in st.get("timeline") or []:
                if r[bi]:
                    _BTC_DAYS[1][r[di]] = len(_BTC_DAYS[0])
                    _BTC_DAYS[0].append(r[bi])
    k = _BTC_DAYS[1].get(day)
    return None if k is None else _BTC_DAYS[0][max(0, k - n + 1):k + 1]


def rel_for_bar(symbol, htf, i, open_ms, bar_ms, price):
    """Verdictul analistului pe token la bara i (core/relative.verdict, aceeasi functie ca live):
    inchiderile zilnice ale tokenului, agregate din lumanarile de baza (doar zile inchise), si
    ale BTC pentru ACEEASI ultima zi. None pentru BTC sau fara date suficiente."""
    if symbol.upper().startswith("BTC/"):
        return None
    closes, counts = htf["1d"]
    tok = closes[max(0, counts[i] - 201):counts[i]]
    btc = btc_closes_until(time.strftime("%Y-%m-%d", time.gmtime((open_ms + bar_ms) / 1000.0 - 86400)), len(tok))
    if not tok or not btc or len(btc) != len(tok):
        return None
    return rel_mod.verdict(tok, btc, price)


def replay_symbol(symbol, candles, weights, start_id):
    """Parcurge istoricul bara cu bara. La fiecare bara vede STRICT trecutul."""
    plans = []
    open_plan = None
    next_id = start_id

    # durata barei = diferenta cea mai frecventa (un gol chiar la inceputul seriei,
    # frecvent la listare, ar fi dat altfel o durata gresita)
    _d = [b[0] - a[0] for a, b in zip(candles[:80], candles[1:81]) if b[0] > a[0]]
    bar_ms = max(set(_d), key=_d.count) if _d else 4 * 3600000
    htf = htf_closes_index(candles, bar_ms)
    for i in range(WARMUP_BARS, len(candles)):
        window = candles[:i + 1]          # <- fara look-ahead: nimic dupa bara i
        bar = candles[i]
        bar_ts = bar[0] / 1000.0

        # 1) evaluez planul deschis pe bara curenta
        if open_plan is not None:
            plan_tracker.evaluate_plan(open_plan, [bar])
            if open_plan["state"] in plan_tracker.CLOSED_STATES:
                plans.append(open_plan)
                open_plan = None

        if open_plan is not None:
            continue  # un singur plan activ per simbol, ca in live (has_open_plan)

        # 2) caut semnal cu exact aceeasi functie ca in live
        scored = scanner.score_symbol(window, weights)
        if not scored:
            continue

        highs = [c[2] for c in window]
        lows = [c[3] for c in window]
        structure = scanner.compute_structure_levels(highs, lows)
        fib = scanner.compute_fibonacci(highs, lows)
        # Aceleasi evidente ca in live. Daca backtest-ul nu le-ar calcula,
        # agentul ar invata din planuri fara evidente si le-ar primi apoi in
        # live - exact nepotrivirea pe care versionarea geometriei o previne.
        bt_ind = scanner.indicators.compute_all(window)
        bt_rsi = scanner.rsi([c[4] for c in window], 14)
        # Aceeasi harta ca in live: se construieste din OHLCV, fara open
        # interest. Forma clusterelor e identica; doar scalarea absoluta
        # lipseste, iar deciziile nu depind de ea.
        bt_liq = liq_mod.build_map(window, scored["price"])
        bt_bias = liq_mod.magnet_bias(bt_liq, scored["price"], scored["direction"])
        # Multi-timeframe din 1d/1w agregate exact din lumanarile de baza (doar
        # perioade inchise). Order book-ul si fluxul de tranzactii nu pot fi
        # reconstruite istoric: lipsesc si sunt excluse din modelul agentului.
        bt_closes = [c[4] for c in window]
        bt_struct = struct_mod.build(
            bt_closes, [c[2] for c in window], [c[3] for c in window],
            scored["atr"], base_tf=scanner.CONFIG["timeframe"],
            fetch_closes=bt_fetch_closes(bt_closes, htf, i, scanner.CONFIG["timeframe"]))
        # Elliott se calculeaza din aceleasi lumanari, deci exista identic in
        # backtest - spre deosebire de order flow.
        bt_ew = ew_mod.analyze([c[2] for c in window], [c[3] for c in window],
                               [c[4] for c in window], scored["price"])
        bt_ew_bias = ew_mod.bias(bt_ew, scored["direction"])
        bt_liqs = ls_mod.build([c[2] for c in window], [c[3] for c in window],
                               [c[4] for c in window], scored["atr"],
                               scored["price"], scanner.CONFIG["timeframe"])
        bt_liqs_bias = ls_mod.bias(bt_liqs, scored["direction"])
        bt_ev = ev_mod.build_evidence(bt_ind, scored["price"], scored["atr"],
                                      bt_rsi, scored.get("components"),
                                      liq=bt_liq, liq_bias=bt_bias,
                                      struct=bt_struct,
                                      ew=bt_ew, ew_bias=bt_ew_bias,
                                      liqs=bt_liqs, liqs_bias=bt_liqs_bias,
                                      alt=alt_for_bar(bar[0], bar_ms), symbol=symbol,
                                      direction=scored["direction"],
                                      rel=rel_for_bar(symbol, htf, i, bar[0], bar_ms, scored["price"]))
        levels = scanner.compute_trade_plan(
            scored["direction"], scored["price"], scored["atr"], structure, fib)
        if not levels:
            continue

        risk = abs(levels["entry"] - levels["sl"])
        if risk <= 0:
            continue

        open_plan = {
            "id": next_id,
            "symbol": symbol,
            "direction": scored["direction"],
            "created_ts": bar_ts,
            "created_time": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(bar_ts)),
            "entry": levels["entry"], "sl": levels["sl"],
            "tp1": levels["tp1"], "tp2": levels["tp2"],
            "risk": risk,
            "planned_r_tp2": round(abs(levels["tp2"] - levels["entry"]) / risk, 2),
            # BUG FIX: aici era STATE_OPEN, deci backtest-ul intra DIRECT la
            # pretul de pullback, fara sa astepte ca pretul sa revina acolo.
            # Scanarea live creeaza planurile ca PENDING si le intra doar daca
            # pretul chiar se intoarce; altfel expira NO_ENTRY, fara pierdere.
            # Cu STATE_OPEN, backtest-ul masura o strategie care nu exista -
            # exact greseala pe care backtest-ul trebuia sa o previna.
            "state": plan_tracker.STATE_PENDING,
            "state_detail": "OPEN",
            "realized_r": None, "closed_ts": None, "bars_checked": 0,
            "score_at_entry": scored["risk_adjusted"],
            # Doar vectorul numeric, nu si lista cu etichete: agentul citeste
            # `components`, iar planurile de backtest nu se afiseaza individual.
            # Cu lista inclusa, cele ~27.000 de planuri ajungeau la 87 MB.
            "components": {**(scored.get("components") or {}),
                           **ev_mod.evidence_features(bt_ev, scored["direction"])},
            "persistence_at_entry": 0,
            "decision": {"action": "ISSUE", "mode": "BACKTEST",
                         "reason": "replay istoric, fara poarta de decizie"},
            "geometry": plan_tracker.GEOMETRY_VERSION,
            "fv": plan_tracker.FEATURE_VERSION,
            "bar_seconds": scanner.timeframe_seconds(),
            "source": "backtest",
        }
        next_id += 1

    return plans, next_id


# ============================ VARIANTE DE INTRARE ===========================
# Diagnostic pe planurile reale: LONG castiga 15.4%, SHORT 14.3% - ambele
# directii pierdeau simetric, deci problema nu e regimul de piata ci intrarea.
# Simularea a aratat ca managementul pozitiei (50% la TP1 vs 100% la TP2)
# schimba rezultatul cu 0.003R - neglijabil. Semnalul de intrare e tot.
# Variantele de mai jos se testeaza pe date REALE, ca sa decida evidenta.

VARIANTS = {
    "actual": {},
    "rsi_strans": {"rsi_long": (50, 65), "rsi_short": (35, 50)},
    "rsi_larg": {"rsi_long": (40, 80), "rsi_short": (20, 60)},
    "contra_trend": {"reverse": True},          # diagnostic: are semnalul avantaj invers?
    "sl_larg": {"sl_atr": 2.5},
    "sl_strans": {"sl_atr": 1.0},
    "fara_pullback": {"pullback": 0.0},
    "pullback_mare": {"pullback": 1.0},
}


# Cost pe tranzactie, exprimat ca procent din pret (dus-intors: taxe + spread).
# ESENTIAL pentru o comparatie corecta: fara el, sweep-ul favorizeaza mereu
# stopurile minuscule, pentru ca R se calculeaza impartind la risc - un risc mai
# mic umfla R fara niciun avantaj real. Costul in R = cost_pct / risc_pct, deci
# penalizeaza exact configuratiile care par bune doar prin micsorarea numitorului.
ROUNDTRIP_COST_PCT = 0.001   # 0.1% dus-intors, tipic pe spot


def cost_in_r(plan):
    risk_pct = abs(plan["entry"] - plan["sl"]) / plan["entry"] if plan.get("entry") else 0
    return ROUNDTRIP_COST_PCT / risk_pct if risk_pct > 0 else 0


def apply_variant(cfg):
    """Aplica temporar o varianta peste parametrii globali."""
    saved = {
        "pullback": scanner.PULLBACK_ATR, "sl_atr": scanner.SL_ATR,
        "rsi_long": scanner.RSI_LONG, "rsi_short": scanner.RSI_SHORT,
        "reverse": scanner.REVERSE_SIGNAL, "tp1_frac": plan_tracker.TP1_FRACTION,
    }
    scanner.PULLBACK_ATR = cfg.get("pullback", saved["pullback"])
    scanner.SL_ATR = cfg.get("sl_atr", saved["sl_atr"])
    scanner.RSI_LONG = cfg.get("rsi_long", saved["rsi_long"])
    scanner.RSI_SHORT = cfg.get("rsi_short", saved["rsi_short"])
    scanner.REVERSE_SIGNAL = cfg.get("reverse", saved["reverse"])
    plan_tracker.TP1_FRACTION = cfg.get("tp1_frac", saved["tp1_frac"])
    return saved


def restore_variant(saved):
    scanner.PULLBACK_ATR = saved["pullback"]
    scanner.SL_ATR = saved["sl_atr"]
    scanner.RSI_LONG = saved["rsi_long"]
    scanner.RSI_SHORT = saved["rsi_short"]
    scanner.REVERSE_SIGNAL = saved["reverse"]
    plan_tracker.TP1_FRACTION = saved["tp1_frac"]


def run_sweep(symbols, histories, weights):
    """Ruleaza fiecare varianta pe aceleasi date si compara. Aceleasi lumanari
    pentru toate variantele, deci diferentele vin doar din configuratie."""
    print("\n" + "=" * 74)
    print("SWEEP DE VARIANTE - aceleasi date, configuratii diferite")
    print("=" * 74)
    print(f"{'varianta':18s} {'inchise':>8s} {'castig%':>9s} {'R brut':>9s} {'R net':>9s} {'PF net':>7s}")
    print("-" * 74)

    rows = []
    for name, cfg in VARIANTS.items():
        saved = apply_variant(cfg)
        allp, nid = [], 1
        for sym, candles in histories.items():
            pl, nid = replay_symbol(sym, candles, weights, nid)
            allp.extend(pl)
        restore_variant(saved)

        closed = [x for x in allp if x.get("realized_r") is not None]
        if not closed:
            print(f"{name:18s} {'0':>8s} {'-':>9s} {'-':>9s} {'-':>9s} {'-':>6s}")
            continue
        gross = [x["realized_r"] for x in closed]
        # planurile NO_ENTRY nu au costat nimic - nu s-a intrat in piata
        net = [g - (cost_in_r(x) if x.get("state") != plan_tracker.STATE_NO_ENTRY else 0)
               for g, x in zip(gross, closed)]
        wins = [r for r in net if r > 0]
        losses = [abs(r) for r in net if r < 0]
        pf = (sum(wins) / sum(losses)) if losses else float("inf")
        rows.append((name, len(closed), 100 * len(wins) / len(closed),
                     sum(gross) / len(gross), sum(net) / len(net), pf))
        print(f"{name:18s} {len(closed):8d} {100*len(wins)/len(closed):8.1f}% "
              f"{sum(gross)/len(gross):+9.3f} {sum(net)/len(net):+9.3f} {pf:7.2f}")

    if rows:
        best = max(rows, key=lambda r: r[4])
        print("-" * 74)
        print(f"R net = R brut minus {100*ROUNDTRIP_COST_PCT:.2f}% cost dus-intors, "
              f"convertit in R. Compara dupa R NET.")
        print(f"Cea mai buna: {best[0]} ({best[4]:+.3f}R net pe plan, {best[1]} planuri)")
        if best[4] <= 0:
            print("\nATENTIE: nicio varianta nu e profitabila pe aceste date.")
            print("Asta inseamna ca logica de semnal actuala nu are avantaj pe "
                  "aceste simboluri/perioada - nu ca trebuie reglati parametrii.")
    return rows


# ===================== VALIDARE WALK-FORWARD ==============================

def walk_forward(plans, n_windows=6, min_train=400, mode="anchored"):
    """Validare walk-forward pe ferestre multiple.

    DE CE E NECESARA: calibrarea invata pragurile din rezultate, iar poarta de
    decizie le foloseste ca sa filtreze. Daca masori filtrul pe ACELEASI date din
    care a invatat, rezultatul e circular - arata bine pentru ca a fost potrivit
    pe ele. Masurat asa, poarta parea sa duca sistemul de la -0.171R la +0.041R;
    pe date nevazute, cifra e alta.

    Pentru fiecare fereastra de test: calibrez DOAR pe ce s-a inchis inainte de
    ea, apoi aplic poarta pe fereastra si masor rezultatul. Niciun plan nu e
    evaluat cu o calibrare care l-a vazut.

    mode="anchored": antrenamentul creste (toata istoria de dinainte).
    mode="rolling":  antrenamentul e o fereastra fixa care aluneca - se
                     adapteaza mai bine la schimbari de regim, dar are mai
                     putine date.
    """
    usable = [p for p in plans
              if p.get("realized_r") is not None
              and p.get("state") != plan_tracker.STATE_NO_ENTRY
              and p.get("closed_ts")]
    usable.sort(key=lambda p: p["closed_ts"])
    n = len(usable)
    if n < min_train + n_windows * 30:
        print(f"\n[!] Prea putine planuri inchise ({n}) pentru {n_windows} ferestre "
              f"cu minim {min_train} la antrenare. Sar peste walk-forward.")
        return None

    start = max(min_train, n // (n_windows + 1))
    edges = [start + round(i * (n - start) / n_windows) for i in range(n_windows + 1)]

    print("\n" + "=" * 74)
    print(f"WALK-FORWARD ({mode}) - {n_windows} ferestre, {n} planuri inchise")
    print("=" * 74)
    print(f"{'fereastra':12s} {'antren':>8s} {'test':>6s} {'emise':>6s} "
          f"{'%emise':>7s} {'R emise':>9s} {'R toate':>9s}")
    print("-" * 74)

    all_issued, all_test = [], []
    for i in range(n_windows):
        lo, hi = edges[i], edges[i + 1]
        test = usable[lo:hi]
        train = usable[:lo] if mode == "anchored" else usable[max(0, lo - min_train):lo]
        if len(train) < min_train or not test:
            continue
        cal = plan_tracker.build_calibration({"plans": train})
        issued = [p["realized_r"] for p in test
                  if plan_tracker.decide(
                      cal, {"risk_adjusted": p.get("score_at_entry") or 0})["action"] == "ISSUE"]
        every = [p["realized_r"] for p in test]
        all_issued += issued
        all_test += every
        r_iss = (sum(issued) / len(issued)) if issued else 0.0
        print(f"{'#' + str(i + 1):12s} {len(train):8d} {len(test):6d} {len(issued):6d} "
              f"{100 * len(issued) / len(test):6.0f}% {r_iss:+9.4f} "
              f"{sum(every) / len(every):+9.4f}")

    if not all_issued:
        print("-" * 74)
        print("Poarta nu a emis niciun plan pe ferestrele de test.")
        return None

    print("-" * 74)
    m = sum(all_issued) / len(all_issued)
    var = sum((x - m) ** 2 for x in all_issued) / max(len(all_issued) - 1, 1)
    ci = 1.96 * math.sqrt(var / len(all_issued))
    m_all = sum(all_test) / len(all_test)
    wins = [x for x in all_issued if x > 0]
    losses = [abs(x) for x in all_issued if x <= 0]
    pf = (sum(wins) / sum(losses)) if losses else float("inf")

    print(f"AGREGAT OUT-OF-SAMPLE ({len(all_issued)} planuri emise din {len(all_test)}):")
    print(f"  R mediu emise : {m:+.4f}  (IC95 {m - ci:+.4f} .. {m + ci:+.4f})")
    print(f"  R mediu toate : {m_all:+.4f}   -> poarta adauga {m - m_all:+.4f}R/plan")
    print(f"  rata de castig: {100 * len(wins) / len(all_issued):.1f}%  |  profit factor {pf:.2f}")
    if wins and losses:
        aw, al = sum(wins) / len(wins), sum(losses) / len(losses)
        print(f"  castig {aw:+.2f}R / pierdere {al:.2f}R = raport {aw / al:.2f}:1 "
              f"(break-even la {100 * al / (aw + al):.0f}%)")
    print()
    if m - ci > 0:
        print("  VERDICT: pozitiv SI semnificativ statistic pe date nevazute.")
    elif m > 0:
        print(f"  VERDICT: pozitiv dar NU semnificativ - intervalul include zero.")
        need = int(var / (m / 1.96) ** 2) + 1 if m > 0 else 0
        print(f"  Ar fi nevoie de ~{need} planuri emise pentru semnificatie la acest efect.")
    else:
        print("  VERDICT: negativ pe date nevazute - filtrul nu se transfera.")
    return {"mean": m, "ci": ci, "n": len(all_issued)}


# Backtest-ul cere `days` de zile, dar bursa da cat are. Raportul de acoperire
# arata exact cat a primit fiecare simbol, ca sa nu existe iluzia ca toate au
# istoric egal. Cu 3650 de zile cerute, simbolurile vechi dau tot ce au (OKX
# limiteaza la ~5 ani pe 4h), iar cele noi dau cat exista de la listare -
# adica exact "toata durata de viata" pentru fiecare.
DEPTH_NOTE = True


def main():
    days = DEFAULT_DAYS
    if "--days" in sys.argv:
        days = int(sys.argv[sys.argv.index("--days") + 1])
    merge = "--merge" in sys.argv
    sweep = "--sweep" in sys.argv
    wf = "--walk-forward" in sys.argv
    wf_mode = "rolling" if "--rolling" in sys.argv else "anchored"
    n_windows = 6
    if "--windows" in sys.argv:
        n_windows = int(sys.argv[sys.argv.index("--windows") + 1])

    live_store = load_json(PLANS_FILE, {"next_id": 1, "plans": []}) if merge else None
    if merge:
        # GARDA DE FAMILIE, inainte de orice descarcare: un backtest pe alt timeframe decat
        # scanarea live ar arhiva planurile live la integrare (vezi data_reset.check_family).
        err = data_reset.check_family(live_store, plan_tracker.GEOMETRY_FAMILY)
        if err:
            raise SystemExit("[EROARE] " + err)
        if data_reset.needs_rebuild(live_store):
            print("[i] Integrarea acestui backtest RECONSTRUIESTE memoria agentului de la zero "
                  "(epoca de date noua) - vezi data_reset.py.")

    exchange, markets, tickers, _, exchange_id = scanner.connect_exchange(scope=None)
    symbols = resolve_symbols(exchange, markets, tickers)
    if not symbols:
        raise SystemExit("Niciun simbol de testat.")

    missing = [s_ for s_ in (scanner.CONFIG.get("watchlist") or []) if s_ not in symbols]
    if missing:
        print(f"\n[!] NEREZOLVATE pe {exchange_id}: {', '.join(missing)}")
        print("    Nu exista ca pereche pe aceasta bursa. Optiuni: adauga un alias")
        print("    in CONFIG['aliases'], scoate-le din watchlist, sau schimba bursa.")

    print(f"\nBacktest pe {exchange_id}: {len(symbols)} simboluri, {days} zile, "
          f"timeframe {scanner.CONFIG['timeframe']}")
    for base, sym in symbols.items():
        print(f"  {base:6s} -> {sym}")

    # Ponderile de scor: inghetate (politica scrisa la reconstructie), neutre la o reconstructie
    # de la zero, altfel weights.json - aceleasi pe care le va folosi scanarea live dupa integrare.
    weights, w_src = data_reset.scoring_weights(live_store if merge else load_json(PLANS_FILE, {}))
    print(f"Ponderi de scor: {weights} ({w_src})")

    histories = {}
    all_plans = []
    next_id = 1
    for base, sym in symbols.items():
        print(f"\nDescarc {sym}...", end=" ", flush=True)
        candles = fetch_history(exchange, sym, scanner.CONFIG["timeframe"], days)
        if len(candles) < WARMUP_BARS + 50:
            print(f"prea putine date ({len(candles)} bare) - sar peste")
            continue
        span = (candles[-1][0] - candles[0][0]) / 86400000
        print(f"{len(candles)} bare ({span:.0f} zile). Rulez replay...", end=" ", flush=True)
        histories[sym] = candles
        plans, next_id = replay_symbol(sym, candles, weights, next_id)
        closed = [p for p in plans if p.get("realized_r") is not None]
        total_r = sum(p["realized_r"] for p in closed)
        print(f"{len(closed)} planuri inchise, {total_r:+.1f}R")
        all_plans.extend(plans)

    if sweep:
        run_sweep(symbols, histories, weights)
        return

    if wf:
        walk_forward(all_plans, n_windows=n_windows, mode=wf_mode)

    # RAPORT DE ACOPERIRE: bursele limiteaza adancimea istoricului pe lumanari
    # de 1h (frecvent 1-2 ani), iar unele tokene nici nu existau acum 5 ani.
    # Fara raportul asta, cerand 1825 de zile ai primi tacit mult mai putin si
    # ai crede ca ai testat pe 5 ani.
    print("\n" + "=" * 60)
    print("ACOPERIRE REALA (cerut vs primit):")
    short = []
    for sym, candles in sorted(histories.items()):
        got = (candles[-1][0] - candles[0][0]) / 86400000 if len(candles) > 1 else 0
        pct = 100 * got / days if days else 0
        flag = ""
        if pct < 80:
            flag = "  <- mult sub cerut"
            short.append((sym, got))
        print(f"  {sym:16s} {got:6.0f} zile din {days} cerute ({pct:3.0f}%){flag}")
    if short:
        print(f"\n  {len(short)}/{len(histories)} simboluri sub 80% din perioada ceruta.")
        print("  Cauze: limita de adancime a bursei, sau tokenul nu exista atunci.")
        print("  Rezultatele agregate sunt dominate de simbolurile cu istoric lung.")

    closed = [p for p in all_plans if p.get("realized_r") is not None]
    if not closed:
        print("\nNiciun plan inchis - verifica datele sau parametrii.")
        return

    store = {"next_id": next_id, "plans": all_plans,
             # cine a generat backtest-ul: merge_backtest.py integreaza la o reconstructie doar un
             # backtest generat de codul curent (data_reset.backtest_is_current)
             "meta": {"fv": plan_tracker.FEATURE_VERSION, "data_epoch": data_reset.audit_core.DATA_EPOCH,
                      "geometry": plan_tracker.GEOMETRY_VERSION, "weights": weights,
                      "generated": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())}}
    store["calibration"] = plan_tracker.build_calibration(store)
    store["summary"] = plan_tracker.summarize(store)
    save_json(BACKTEST_FILE, store, compact=True)

    print("\n" + "=" * 60)
    plan_tracker.print_summary(store)
    print("\nCALIBRARE MASURATA (rata reala pe interval de scor):")
    for b in sorted(store["calibration"], key=int):
        e = store["calibration"][b]
        flag = "" if e["reliable"] else "  (prea putine date)"
        print(f"  scor {b}-{int(b)+19}: {e['win_rate']:5.1f}% "
              f"(IC {e['ci_low']:.0f}-{e['ci_high']:.0f}%) "
              f"R mediu {e['avg_r']:+.3f}  n={e['total']}{flag}")

    span_days = (max(p["closed_ts"] for p in closed) -
                 min(p["created_ts"] for p in all_plans)) / 86400
    print(f"\nAcoperire calendaristica: {span_days:.0f} zile "
          f"(pragul agentului: {21} zile)")
    print(f"Salvat in {BACKTEST_FILE}")

    if merge:
        live = live_store
        if data_reset.needs_rebuild(live):
            # RECONSTRUCTIE: o singura data pe epoca de date. Planurile de backtest noi se
            # numeroteaza dupa cele existente; tot restul (ce se scoate, ce se sterge, ponderile
            # inghetate) e in data_reset.rebuild.
            offset = live.get("next_id", 1)
            for i, p in enumerate(all_plans):
                p["id"] = offset + i
            live["next_id"] = offset + len(all_plans)
            data_reset.rebuild(live, all_plans, weights, plan_tracker.same_family,
                               plan_tracker.GEOMETRY_FAMILY, plan_tracker.FEATURE_VERSION)
            live["calibration"] = plan_tracker.build_calibration(live)
            live["summary"] = plan_tracker.summarize(live)
            plan_tracker.save_plans(live)
            print(f"\nMemoria reconstruita: {len(live['plans'])} planuri in {PLANS_FILE}. "
                  "Pasul urmator al workflow-ului antreneaza agentul de la zero.")
            return

        # DEDUPLICARE, dupa identitatea stabila a planului.
        # merge_backtest.py avea aceasta verificare; backtest.py --merge NU o
        # avea, desi workflow-ul foloseste exact aceasta cale. O a doua rulare
        # de backtest pe aceeasi perioada ar fi introdus fiecare plan de doua
        # ori, iar agentul ar fi invatat fiecare exemplu dublu - crescandu-i
        # artificial increderea pe date care nu sunt noi. Cheia nu include
        # `id`, fiindca id-ul se reatribuie la fiecare integrare.
        def plan_key(p):
            return (p.get("symbol"), p.get("direction"), p.get("created_ts"),
                    p.get("geometry"), round(p.get("entry") or 0, 10))

        # REGENERARE, nu doar adaugare. Un backtest reproduce TOATE planurile
        # familiei curente cu logica de acum. Deduplicarea singura le sarea pe
        # cele existente, deci caracteristicile calculate cu o logica veche
        # (Elliott, lichidare) ramaneau vechi pentru totdeauna. Inlocuiesc
        # planurile de backtest ale familiei; cele live raman neatinse.
        old_bt = {id(p) for p in live["plans"]
                  if p.get("source") == "backtest"
                  and plan_tracker.same_family(p.get("geometry", "v1"))}
        if old_bt:
            live["plans"] = [p for p in live["plans"] if id(p) not in old_bt]
            print(f"  Inlocuiesc {len(old_bt)} planuri de backtest ale familiei "
                  f"{plan_tracker.GEOMETRY_FAMILY} cu cele regenerate acum.")
            # Agentul invatase planurile vechi; le-ar invata din nou peste ele.
            # Il reantrenez de la zero pe datele noi (pasul urmator din workflow).
            agent_file = os.path.join(DATA_DIR, "agent_model.json")
            if os.path.exists(agent_file):
                os.remove(agent_file)
                print("  Modelul agentului sters - se reantreneaza de la zero pe datele noi.")

        existing = {plan_key(p) for p in live["plans"] if p.get("source") == "backtest"}
        fresh = [p for p in all_plans if plan_key(p) not in existing]
        skipped = len(all_plans) - len(fresh)
        if skipped:
            print(f"  {skipped} planuri erau deja integrate - le sar.")
        if not fresh:
            print("  Nimic nou de integrat; plans.json ramane neschimbat.")
            plan_tracker.save_plans(live)
            return

        offset = live.get("next_id", 1)
        for i, p in enumerate(fresh):
            p["id"] = offset + i
        live["plans"].extend(fresh)
        live["next_id"] = offset + len(fresh)
        all_plans = fresh
        live["calibration"] = plan_tracker.build_calibration(live)
        live["summary"] = plan_tracker.summarize(live)
        # BUG CRITIC: aici se scria cu save_json direct, ocolind COMPLET garda
        # de dimensiune din plan_tracker.save_plans - exact motivul pentru care
        # plans.json a ajuns la 100.83 MB si push-ul a fost respins de GitHub.
        # save_plans() e singura functie care: (1) scrie compact, fara indent,
        # (2) pastreaza lista de evidente doar pe ultimele KEEP_EVIDENCE_ON
        # planuri, (3) taie automat cele mai vechi planuri daca tot depaseste
        # SIZE_FAIL_MB. backtest.py trebuia sa treaca prin ea de la inceput.
        plan_tracker.save_plans(live)
        print(f"\nAdaugate {len(all_plans)} planuri in {PLANS_FILE} (marcate source=backtest).")
        print("Ruleaza acum `python3 ai_agent.py` ca agentul sa invete din ele.")
    else:
        print("\nRuleaza cu --merge daca vrei ca agentul sa invete din aceste rezultate.")


if __name__ == "__main__":
    main()
