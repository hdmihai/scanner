#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crypto_ai_scanner.py
=====================
Scaner de piata crypto cu scor de risc, probabilitate, "memorie" JSON
persistenta si ponderi adaptive (invata din rezultatele trecute).

PORNIRE RAPIDA
--------------
1) pip install ccxt requests
2) Editeaza sectiunea CONFIG de mai jos (mai ales telegram_bot_token si
   telegram_chat_id daca vrei notificari pe telefon).
3) Ruleaza: python3 crypto_ai_scanner.py
4) Programeaza-l sa ruleze periodic (ex: la fiecare ora) cu cron, un task
   scheduler, sau Termux:Boot + termux-job-scheduler daca il rulezi pe telefon.

Unde il tii pornit (gratuit), in ordinea recomandarii:
1. GitHub Actions (vezi .github/workflows/scan.yml alaturat) - ruleaza pe
   infrastructura GitHub, gratuit, fara server de administrat de tine
2. un mini-VPS (ex: Oracle Cloud Free Tier) - daca vrei control total
3. un PC vechi / Raspberry Pi acasa, mereu pornit
4. Termux, direct pe telefon - functioneaza, dar Android poate opri
   scripturile din fundal daca nu dezactivezi optimizarea bateriei pentru
   Termux si nu-l tii scutit de "battery saver"

Nu contine cod care trimite ordine de tranzactionare - doar scaneaza,
scoreaza si notifica. Nu este sfat financiar.
"""

import ccxt
import plan_tracker
import indicators
import evidence as ev_mod
import exchanges as ex_mod
import liquidation as liq_mod
import market_structure as struct_mod
import elliott as ew_mod
import liquidity_structure as ls_mod
import altseason as alt_mod
import ai_agent
import json
import os
import time
import requests
import math
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

# ============================== CONFIG ==============================
CONFIG = {
    # "gateio" a fost redenumit "gate" in ccxt - verificat contra ccxt 4.5.78, unde
    # `gateio` nu mai exista. connect_exchange sarea peste el gracios, deci nu
    # crapa, dar aveai practic 4 rezerve in loc de 5, tacut.
    "exchange_fallback": ["okx", "kucoin", "gate", "mexc", "kraken"],
    # Incearca pe rand, primul care raspunde e folosit - vezi connect_exchange().
    # Kraken primul (serveste SUA, nu are motiv sa geo-blocheze); restul sunt
    # rezerve. NU mai modifica sursa fisierului la runtime (spre deosebire de
    # run_scanner_with_exchange_fallback.py, care trebuie sters - vezi nota
    # din raspuns).
    "quotes": ["USDT", "USDC", "USD"],
    # Mai multe monede de cotare, nu doar USDT: pe Kraken aproape totul e cotat
    # in USD (doar 44 perechi USDT din 1440 de piete), motiv pentru care prima
    # rulare reala a gasit doar 34 de simboluri. Deduplicate pe simbolul de baza.
    "min_universe": 120,       # sub atat, incerc urmatorul exchange din lista
                               # (se ajusteaza automat la marimea watchlist-ului)
    "universe_size": 200,      # cate simboluri intra efectiv in scanare (scor + persistenta)
    "coingecko_scope": 200,    # doar proiectele din top N CoinGecko dupa market cap sunt eligibile

    # WATCHLIST: daca e completata, scaneaza DOAR aceste simboluri si ignora
    # complet top-200 CoinGecko. Lasa lista goala ca sa revii la scanarea larga.
    # Aliasurile acopera redenumirile: GRAM e Toncoin redenumit (iunie 2026), dar
    # unele burse pot inca lista perechea ca TON/USDT. Se ia primul alias gasit.
    # WATCHLIST in trepte. Cele 7 initiale erau toate mid-cap alts cu profil
    # asemanator - date omogene. Treapta 1 adauga capete diferite de spectru:
    # BTC/ETH au volatilitate mult mai mica, DOGE mult mai mare. Diversitatea
    # de ATR conteaza mai mult decat numarul brut de simboluri, pentru ca da
    # regimuri diferite in ACEEASI perioada calendaristica.
    # WATCHLIST: cei 18 propusi de tine in discutiile anterioare (JASMY scos -
    # nu exista ca pereche pe OKX), plus 10 alesi pe rezultate MASURATE pe 5 ani,
    # nu pe intuitie: BTC si ETH pentru capatul de volatilitate mica, DOGE pentru
    # cel mare, iar THETA (+123R), ATOM (+79R), MANA (+76R), GRT (+70R),
    # FLOW (+67R), SOL (+40R), XRP (+30R) pentru ca au dat cele mai bune
    # rezultate in backtest si au istoric complet.
    #
    # Lista mai scurta inseamna mai putine planuri pe zi, deci acumulare mai
    # lenta - dar si mai putin zgomot de la simboluri cu 50 de zile de istoric.
    "watchlist": [
        # propusi de tine
        "ADA", "ALGO", "AVAX", "AXS", "CHZ", "DASH", "DOT", "EGLD", "FET",
        "GRAM", "LINK", "NEAR", "POL", "SEI", "SUI", "TRX", "ZEC", "ZEN",
        # adaugati pe rezultate masurate
        "BTC", "ETH", "SOL", "XRP", "DOGE", "ATOM", "THETA", "GRT", "MANA", "FLOW",
        # Doi din top 100 cu cel mai mare multiplu pana la ATH: ambii ~99.7%
        # sub maxim, deci peste 300x pe criteriul cerut. I-am ales dintre cei
        # profund scazuti pentru ca se disting de proiectele moarte - ICP are a
        # treia cea mai mare activitate de dezvoltare din crypto, iar Filecoin
        # conduce industria la commit-uri zilnice pe GitHub.
        #
        # CAVEAT, pentru ca nu vreau sa para altceva decat e: distanta fata de
        # ATH NU e o masura a valorii. Maximul a fost un pret care a existat o
        # clipa in conditii specifice, nu o valoare la care activul are dreptul
        # sa revina. Backtest-ul va spune daca produc planuri bune; criteriul
        # ATH spune doar ca au spatiu, nu ca il vor parcurge.
        "ICP", "FIL",
    ],
    # Redenumiri de care sunt sigur. Backtest-ul alege aliasul cu istoricul
    # cel mai adanc, nu pe cel cu volumul mai mare.
    "aliases": {"POL": ["POL", "MATIC"], "EGLD": ["EGLD", "ERD"]},
    # Configurabil din mediu, ca sa poata fi schimbat din workflow fara sa
    # editezi codul. Backtest-ul citeste acelasi CONFIG, deci scanarea si
    # backtest-ul raman mereu pe acelasi timeframe.
    "timeframe": os.environ.get("SCAN_TIMEFRAME", "1h"),
    # 260, nu 200: EMA 200 are nevoie de 200 de bare, iar bara neinchisa se
    # elimina - la 200 ramaneau 199 si Golden/Death Cross ar fi lipsit MEREU,
    # tacut. Prins la verificarea panoului de structura, unde cross-ul aparea
    # gol in productie desi codul era corect.
    "candles": 260,
    "lookahead_hours": 24,     # dupa cate ore evaluam daca un semnal a "nimerit"
    "hit_threshold_atr": 0.5,  # miscare minima (in ATR-uri) ca sa conteze "hit"
    # Plafonul REAL de volum: se deschid planuri doar pentru top N pe directie,
    # deci un univers de 200 ar da tot 10 planuri/scanare cu N=5.
    "top_n_per_direction": 8,
    "chart_candles": 80,       # cate lumanari pastram pentru graficul din dashboard
    "telegram_bot_token": os.environ.get("TELEGRAM_BOT_TOKEN", "PUNE_AICI_TOKEN_DE_LA_BOTFATHER"),
    "telegram_chat_id": os.environ.get("TELEGRAM_CHAT_ID", "PUNE_AICI_CHAT_ID_UL_TAU"),
    "data_dir": "data",
}

HISTORY_FILE = os.path.join(CONFIG["data_dir"], "scan_history.json")
WEIGHTS_FILE = os.path.join(CONFIG["data_dir"], "weights.json")
WEIGHTS_HISTORY_FILE = os.path.join(CONFIG["data_dir"], "weights_history.json")
CHART_FILE = os.path.join(CONFIG["data_dir"], "latest_chart.json")
DETAILS_FILE = os.path.join(CONFIG["data_dir"], "latest_details.json")
EXCHANGES_FILE = os.path.join(CONFIG["data_dir"], "exchanges.json")
EXCHANGE_SCANS_FILE = os.path.join(CONFIG["data_dir"], "exchange_scans.json")

# MODULELE PER BURSA. Fiecare bursa conectata primeste ANALIZA COMPLETA - scor,
# detalii pe token (grafic, Elliott, structura, lichidare), evidente si decizia pe
# care ar lua-o agentul - prin adaptorul ei din adapters/exchanges/.
#
# INVATAREA ramane doar pe bursa activa: acelasi token are practic acelasi pret pe
# toate bursele (arbitrajul le aliniaza), iar cinci planuri aproape identice ar
# numara fiecare rezultat de cinci ori - AUC-ul si confirmarea live ar deveni
# artificial de bune. Propunerile de pe celelalte burse se calculeaza si se
# afiseaza, marcate "neantrenat".
SECONDARY_SCAN_LIMIT = 30      # = marimea watchlist-ului; plafonul simbolurilor per bursa
EXCHANGE_TIME_BUDGET = 360     # secunde per bursa secundara; bursele ruleaza IN PARALEL,
                               # deci scanarea creste cu cea mai lenta (Kraken: 1 cerere/s)
EXCHANGE_HISTORY_KEEP = 60     # scanari pastrate per bursa, pentru persistenta semnalelor
EXCHANGES_DIR = os.path.join(CONFIG["data_dir"], "exchanges")
# ORDER BOOK-UL FIECARUI SEMNAL. Pana acum se descarca o singura carte - a celui mai
# bun candidat - si se folosea pentru TOATE semnalele: zidurile de lichiditate si
# dezechilibrul cartii afisate la fiecare token veneau de la alt token (aceeasi clasa
# de eroare ca "NEAR sub nor"). Deciziile nu erau afectate - ev_book_imbalance e
# exclusa din agent - dar afisarea si memoria planurilor da. Costa cel mult 15
# apeluri in plus pe scanare.
PER_SIGNAL_ORDER_BOOK = True
CHART_BARS_MAX = 170      # plafonul ferestrei adaptive per token
CHART_BARS = 90           # lumanari per token. 120 dadea ~2.4 MB de pagina
                          # la 30 de tokenuri; 90 pastreaza structura vizibila.
SPARKLINE_BARS = 40   # cate preturi de inchidere pastrez pentru graficul mic

DEFAULT_WEIGHTS = {"trend": 1.0, "momentum": 1.0, "volatility": 1.0, "volume": 1.0}


# ============================ INDICATORI =============================
# Implementati simplu, in Python pur, fara pandas/numpy - ca sa mearga
# usor si pe un VPS minimal sau pe telefon (Termux).

def timeframe_seconds():
    """Durata unei lumanari, in secunde, derivata din CONFIG['timeframe'].
    Necesara ca expirarea pullback-ului sa fie masurata in timp, nu in numarul
    de bare primite intr-un apel - vezi nota din plan_tracker.evaluate_plan."""
    tf = CONFIG.get("timeframe", "1h")
    units = {"m": 60, "h": 3600, "d": 86400, "w": 604800}
    try:
        return int(tf[:-1]) * units[tf[-1]]
    except (ValueError, KeyError):
        return 3600


def round_price(value, sig=8):
    """Rotunjeste la cifre SEMNIFICATIVE, nu la un numar fix de zecimale.

    BUG FIX: peste tot se folosea `round(x, 6)`. Pentru o moneda la 0.0000234,
    ATR-ul tipic (~2%) e 0.00000047, care rotunjit la 6 zecimale devine 0.0.
    De aici `compute_trade_plan` returna None si scannerul crapa cu
    "TypeError: 'NoneType' object is not subscriptable".

    Chiar si cand nu crapa, era gresit: la un pret de 0.00000089, entry, SL,
    TP1 si TP2 deveneau toate 0.000001 - planul aratand valid, dar complet
    inutil. Universul top-200 contine multe monede sub 0.0001, deci problema
    afecta o parte reala din scanari, tacut.
    """
    if value is None or value == 0:
        return value
    exponent = math.floor(math.log10(abs(value)))
    decimals = max(0, min(sig - 1 - exponent, 18))
    return round(value, decimals)


def ema(values, period):
    if len(values) < period:
        return None
    k = 2 / (period + 1)
    e = sum(values[:period]) / period
    for v in values[period:]:
        e = v * k + e * (1 - k)
    return e


def rsi(closes, period=14):
    if len(closes) < period + 1:
        return 50.0
    gains, losses = [], []
    for i in range(1, len(closes)):
        diff = closes[i] - closes[i - 1]
        gains.append(max(diff, 0))
        losses.append(max(-diff, 0))
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def atr(highs, lows, closes, period=14):
    if len(closes) < period + 1:
        return None
    trs = []
    for i in range(1, len(closes)):
        trs.append(max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i - 1]),
            abs(lows[i] - closes[i - 1]),
        ))
    return sum(trs[-period:]) / period


def ema_series_full(values, period):
    """La fel ca ema(), dar returneaza toata seria (pentru desenat pe grafic in dashboard), nu doar ultima valoare."""
    if len(values) < period:
        return [None] * len(values)
    k = 2 / (period + 1)
    series = [None] * (period - 1)
    e = sum(values[:period]) / period
    series.append(e)
    for v in values[period:]:
        e = v * k + e * (1 - k)
        series.append(e)
    return series


# ==================== STRUCTURA, FIBONACCI, PLAN DE TRADE =================
# Adaugate ca sa acopere sectiunile "AI Plan" / "Market Structure" /
# "Fibonacci" din dashboard-ul de referinta. Sunt euristici transparente,
# nu o reconstructie a vreunui produs anume - le poti inlocui oricand cu
# propria ta logica din AI_Dashboard_v10.pine.

def find_swing_points(highs, lows, lookback=5):
    """Puncte de swing simple: un maxim/minim local mai extrem decat 'lookback' lumanari de fiecare parte."""
    swing_highs, swing_lows = [], []
    for i in range(lookback, len(highs) - lookback):
        if highs[i] == max(highs[i - lookback:i + lookback + 1]):
            swing_highs.append(highs[i])
        if lows[i] == min(lows[i - lookback:i + lookback + 1]):
            swing_lows.append(lows[i])
    return swing_highs, swing_lows


def compute_structure_levels(highs, lows, n_levels=3):
    """Niveluri simple de suport/rezistenta, din cele mai recente puncte de swing (echivalentul S1-S3 / R1-R3 din poza ta)."""
    swing_highs, swing_lows = find_swing_points(highs, lows)
    resistance = sorted(set(round_price(h) for h in swing_highs[-12:]), reverse=True)[:n_levels]
    support = sorted(set(round_price(l) for l in swing_lows[-12:]), reverse=True)[-n_levels:]
    return {"resistance": resistance, "support": support}


def compute_fibonacci(highs, lows, lookback=100):
    """Retracement + extensie Fibonacci pe ultimul swing major (high/low) din fereastra de lookback."""
    swing_high = max(highs[-lookback:])
    swing_low = min(lows[-lookback:])
    diff = swing_high - swing_low
    retracement = {str(r): round_price(swing_high - diff * r) for r in (0.236, 0.382, 0.5, 0.618, 0.786)}
    extension = {str(r): round_price(swing_high + diff * (r - 1)) for r in (1.272, 1.618, 2.0)}
    return {"swing_high": swing_high, "swing_low": swing_low, "retracement": retracement, "extension": extension}


MIN_TP1_R = 1.0   # TP1 nu are voie mai aproape de 1R
MIN_TP2_R = 2.5   # TP2 trebuie sa justifice riscul
PULLBACK_ATR = 0.5  # cat de mult astept sa revina pretul inainte de intrare
SL_ATR = 1.5        # distanta stopului, in ATR
RSI_LONG = (45, 75)   # banda RSI pentru LONG
RSI_SHORT = (25, 55)  # banda RSI pentru SHORT
REVERSE_SIGNAL = False  # diagnostic: inverseaza directia semnalului


def compute_trade_plan(direction, price, atr_val, structure, fib):
    """Plan de tranzactionare: SL pe baza de ATR, TP1 la prima structura
    relevanta, TP2 la extensia Fibonacci 1.618.

    PRAGURI MINIME IN R (adaugate dupa analiza a 47 de planuri reale):
    Varianta initiala lua TP1 direct de la prima structura, fara sa verifice
    cat de departe e. Cand cea mai apropiata rezistenta era la 0.1% iar SL-ul
    la 1.5 ATR, iesea un TP1 la 0.05R - un plan care nu poate castiga. In
    datele reale, 11 din 47 de planuri aveau TP1 sub 0.35R, unul chiar la 0.00R.

    Efectul combinat cu regula "50% la TP1, apoi SL la breakeven": downside
    ramanea -1R intreg, dar upside era taiat la ~0.45R. Castigul mediu masurat
    a iesit 0.506R fata de pierdere medie 1.0R, deci ar fi fost nevoie de
    66.4% rata de succes doar pentru break-even. Observat: 34.8%.

    Acum structura e folosita doar daca ofera macar 1R; altfel TP1 se plaseaza
    la exact 1R. Nu inventez o tinta mai buna decat da piata - doar refuz sa
    generez planuri cu asteptare negativa prin constructie.
    """
    ext_1618 = fib["extension"]["1.618"]
    risk = atr_val * 1.5
    if risk <= 0:
        return None

    # BUG FIX (gasit pe planul real #62 SKR/USDT): varianta anterioara avea un
    # fallback pentru TP2 care nu verifica daca e dincolo de TP1. Cand structura
    # dadea un TP1 foarte departe (8.91R), fallback-ul punea TP2 la 2.50R - deci
    # MAI APROAPE decat TP1. Pretul ar fi atins TP2 primul, planul s-ar fi inchis
    # inregistrand 2.5R desi tinta structurala era la 8.9R, iar etapa TP1 nu s-ar
    # fi declansat niciodata. Acum TP2 e garantat dincolo de TP1, prin constructie.
    # INTRARE PE PULLBACK (v3): nu intru la pretul de semnal, ci astept o
    # revenire de PULLBACK_ATR. SL-ul ramane la nivelul structural (calculat din
    # pretul de semnal), deci riscul se micsoreaza si TP1 devine mult mai
    # aproape in termeni absoluti - 0.5 ATR fata de 1.69 ATR masurat pe planurile
    # v2. Daca pretul nu revine, planul expira fara pierdere.
    pullback = atr_val * PULLBACK_ATR
    entry = price - pullback if direction == "LONG" else price + pullback
    risk = abs(entry - (price - atr_val * SL_ATR if direction == "LONG" else price + atr_val * SL_ATR))
    if risk <= 0:
        return None

    if direction == "LONG":
        sl = price - atr_val * SL_ATR
        above = [r for r in structure["resistance"] if r >= entry + risk * MIN_TP1_R]
        tp1 = min(above) if above else entry + risk * MIN_TP1_R
        tp2_floor = max(tp1 + risk * 0.5, entry + risk * MIN_TP2_R)
        tp2_candidates = [c for c in (ext_1618, price + risk * 4) if c >= tp2_floor]
        tp2 = min(tp2_candidates) if tp2_candidates else tp2_floor
    else:
        sl = price + atr_val * SL_ATR
        below = [s for s in structure["support"] if s <= entry - risk * MIN_TP1_R]
        tp1 = max(below) if below else entry - risk * MIN_TP1_R
        tp2_ceiling = min(tp1 - risk * 0.5, entry - risk * MIN_TP2_R)
        tp2_candidates = [c for c in (ext_1618, price - risk * 4) if c <= tp2_ceiling]
        tp2 = max(tp2_candidates) if tp2_candidates else tp2_ceiling

    expected_r = round(abs(tp2 - entry) / risk, 2)
    return {
        "entry": round_price(entry), "sl": round_price(sl),
        "signal_price": round_price(price),
        "tp1": round_price(tp1), "tp2": round_price(tp2),
        "expected_r": expected_r,
    }


# =============================== SCOR =================================

def score_symbol(ohlcv, weights):
    """Primeste lumanari OHLCV brute de la exchange si returneaza un scor, directie si componente, sau None daca nu exista semnal clar."""
    closes = [c[4] for c in ohlcv]
    highs = [c[2] for c in ohlcv]
    lows = [c[3] for c in ohlcv]
    volumes = [c[5] for c in ohlcv]

    if len(closes) < 60:
        return None

    ema20 = ema(closes[-100:], 20)
    ema50 = ema(closes[-150:], 50)
    r = rsi(closes, 14)
    a = atr(highs, lows, closes, 14)
    price = closes[-1]
    avg_vol = sum(volumes[-20:]) / 20
    vol_now = volumes[-1]

    if not ema20 or not ema50 or not a or a == 0:
        return None

    trend_up = ema20 > ema50
    trend_strength = min(abs(ema20 - ema50) / ema50 * 20, 1.0)

    lo_l, hi_l = RSI_LONG
    lo_s, hi_s = RSI_SHORT
    if trend_up and lo_l <= r <= hi_l:
        direction = "LONG"
        momentum_strength = min((r - lo_l) / max(hi_l - lo_l, 1), 1.0)
    elif (not trend_up) and lo_s <= r <= hi_s:
        direction = "SHORT"
        momentum_strength = min((hi_s - r) / max(hi_s - lo_s, 1), 1.0)
    else:
        return None  # fara semnal clar in acest moment

    if REVERSE_SIGNAL:
        direction = "SHORT" if direction == "LONG" else "LONG"

    atr_pct = a / price
    volatility_score = max(1.0 - abs(atr_pct - 0.02) / 0.02, 0.0)  # favorizeaza ~2% ATR
    volume_score = min(vol_now / avg_vol, 1.5) / 1.5 if avg_vol > 0 else 0.3

    components = {
        "trend": round(trend_strength, 3),
        "momentum": round(momentum_strength, 3),
        "volatility": round(volatility_score, 3),
        "volume": round(volume_score, 3),
    }

    weighted_sum = sum(components[k] * weights.get(k, 1.0) for k in components)
    max_possible = sum(weights.get(k, 1.0) for k in components)
    risk_adjusted = round((weighted_sum / max_possible) * 100) if max_possible else 0
    probability = round(min(50 + risk_adjusted * 0.35, 88), 1)
    expected_r = round(1.5 + (risk_adjusted / 100) * 4, 2)

    return {
        "direction": direction,
        "risk_adjusted": risk_adjusted,
        "probability": probability,
        "expected_r": expected_r,
        "components": components,
        "price": price,
        "atr": round_price(a),
    }


# ============================ LICHIDITATE (SMC) ===========================
# Nivelurile de lichiditate (cele mai mari cluster-e bid/ask din order book)
# sunt un concept central in Smart Money Concepts: zone unde e probabil sa
# reactioneze pretul, pentru ca acolo sta volumul mare de ordine.

def fetch_liquidity_levels(exchange, symbol, depth=100, top_n=3, attempts=None):
    """BUG FIX: nu despachetez cu `for p, a in bids`. Standardul ccxt e
    [pret, cantitate], dar unele exchange-uri adauga un al treilea camp -
    Kraken pune si timestamp-ul nivelului, ceea ce arunca
    "ValueError: too many values to unpack (expected 2)". Iau explicit
    primele doua elemente si ignor restul, indiferent de exchange."""
    # KuCoin accepta doar limit=20 sau 100; alte valori sunt respinse. Incerc
    # valoarea ceruta, apoi variantele acceptate, apoi fara limit deloc.
    ob = None
    # `attempts`: adancimile acceptate de bursa (din adaptorul ei); implicit ca inainte
    for attempt in (attempts or (depth, 20, None)):
        try:
            ob = (exchange.fetch_order_book(symbol, limit=attempt) if attempt
                  else exchange.fetch_order_book(symbol))
            break
        except Exception as e:
            last_err = e
    if ob is None:
        print(f"[!] order book {symbol}: {last_err}")
        return None

    def normalize(levels):
        out = []
        for lvl in levels or []:
            if not lvl or len(lvl) < 2:
                continue
            try:
                price, amount = float(lvl[0]), float(lvl[1])
            except (TypeError, ValueError):
                continue
            out.append({"price": round_price(price), "amount": round_price(amount, 6)})
        return sorted(out, key=lambda d: d["amount"], reverse=True)[:top_n]

    return {"bids": normalize(ob.get("bids")), "asks": normalize(ob.get("asks"))}


def fetch_coingecko_top_symbols(top_n=200):
    """Simbolurile din top N CoinGecko dupa market cap (nu dupa volum de
    schimb) - folosite ca sa restrangem universul la proiecte relevante
    fundamental, nu doar la ce are volum mare pe termen scurt."""
    symbols = set()
    per_page = 250
    pages = (top_n + per_page - 1) // per_page
    for page in range(1, pages + 1):
        url = (f"https://api.coingecko.com/api/v3/coins/markets"
               f"?vs_currency=usd&order=market_cap_desc&per_page={per_page}&page={page}")
        try:
            resp = requests.get(url, timeout=20)
            resp.raise_for_status()
            for coin in resp.json():
                symbols.add(coin["symbol"].upper())
        except Exception as e:
            print(f"[!] CoinGecko top-{top_n} (pagina {page}): {e}")
            break
    return symbols


# =========================== PERSISTENTA JSON ==========================

def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path, "r") as f:
        return json.load(f)


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # SCRIERE ATOMICA: fisier temporar, golit pe disc, apoi inlocuire intr-un singur
    # pas. Un job oprit in timpul scrierii (timeout, anulare) lasa intact fisierul
    # vechi - pasul de commit din workflow ruleaza cu if: always() si ar fi urcat
    # un JSON trunchiat, oprind toate scanarile urmatoare.
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def compute_persistence_and_age(history, symbol, direction, now_ts):
    """Cate scanari recente consecutive au avut acelasi symbol+directie si
    de cand (in minute) e activa aceasta directie pentru acest simbol."""
    streak = 0
    first_ts = now_ts
    for scan in reversed(history):
        match = next((r for r in scan["results"] if r["symbol"] == symbol), None)
        if match and match["direction"] == direction:
            streak += 1
            first_ts = scan["scan_id_ts"]
        else:
            break
    age_minutes = round((now_ts - first_ts) / 60)
    return streak, age_minutes


def evaluate_and_learn(history, weights, tickers, lookahead_hours, hit_threshold_atr):
    """'Invatare' simpla: verifica semnalele mai vechi decat lookahead_hours,
    vede daca pretul s-a miscat in directia prezisa, si ajusteaza usor
    ponderile componentelor care au dat rezultate bune/proaste."""
    now_ts = time.time()
    lookahead_sec = lookahead_hours * 3600
    feedback = {k: [] for k in weights}

    for scan in history:
        if scan.get("evaluated") or now_ts - scan["scan_id_ts"] < lookahead_sec:
            continue
        for r in scan["results"]:
            price_now = tickers.get(r["symbol"], {}).get("last")
            if price_now is None:
                continue
            move = (price_now - r["price"]) if r["direction"] == "LONG" else (r["price"] - price_now)
            hit = move >= r["atr"] * hit_threshold_atr
            r["outcome"] = "hit" if hit else "miss"
            for comp, val in r["components"].items():
                if val > 0.6:
                    feedback[comp].append(1 if hit else -1)
        scan["evaluated"] = True

    for comp, fb in feedback.items():
        if not fb:
            continue
        avg = sum(fb) / len(fb)
        weights[comp] = round(max(0.3, min(2.0, weights[comp] * (1 + avg * 0.05))), 4)

    return weights


# ============================== TELEGRAM ================================

def send_telegram(token, chat_id, text):
    if "PUNE_AICI" in token or "PUNE_AICI" in chat_id:
        print("[!] Configureaza telegram_bot_token si telegram_chat_id in CONFIG "
              "ca sa primesti rezultatele pe telefon.")
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        requests.post(
            url,
            data={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"},
            timeout=10,
        )
    except Exception as e:
        print(f"[!] Eroare trimitere Telegram: {e}")


def format_message(scan):
    """Construieste mesajul Telegram ca un mini-dashboard (tabel monospace),
    vizual apropiat de layout-ul din poza cu ENO AI CORE."""

    def table(rows):
        header = f"{'SYMBOL':<14}{'SCORE':>6}{'PROB':>8}{'PERS':>6}"
        body = [
            f"{r['symbol']:<14}{r['risk_adjusted']:>6}{r['probability']:>7}%{r['persistence']:>6}"
            for r in rows
        ]
        return "```\n" + "\n".join([header] + body) + "\n```" if rows else "_(niciun semnal)_"

    # ASCII pur intentionat: emoji-urile s-au corupt de trei ori la transferul
    # fisierului (UTF-8 citit ca Latin-1), producand caractere ilizibile in mesajele Telegram.
    # Textul simplu nu poate fi corupt de nicio conversie de encoding.
    parts = [f"*SCAN {scan['scan_time']}* - universe {scan['universe_size']}"]
    parts.append("\n*TOP LONG*")
    parts.append(table(scan["top_long"]))
    parts.append("\n*TOP SHORT*")
    parts.append(table(scan["top_short"]))
    if scan.get("best_candidate"):
        b = scan["best_candidate"]
        parts.append(
            f"\n*BEST CANDIDATE:* {b['symbol']} {b['direction']} - "
            f"conf {b['probability']}% - exp {b['expected_r']}R"
        )
    return "\n".join(parts)


# ================================ MAIN ===================================

def build_eligible_pairs(markets, tickers, scope):
    """Construieste lista de perechi eligibile, cu doua imbunatatiri fata de
    varianta initiala:

    1. MAI MULTE MONEDE DE COTARE. Prima rulare reala a gasit doar 34 de
       simboluri pe Kraken, pentru ca acolo aproape totul e cotat in USD, nu
       USDT (44 perechi USDT din 1440 de piete). Accept acum USDT/USDC/USD.
    2. DEDUPLICARE PE SIMBOL DE BAZA. BTC/USDT si BTC/USD sunt acelasi
       proiect - pastrez varianta cu volum mai mare, ca sa nu apara de doua
       ori in universul scanat si sa umfle artificial numararea."""
    by_base = {}
    for symbol, m in markets.items():
        if not m.get("active", True):
            continue
        parts = symbol.split("/")
        if len(parts) != 2:
            continue
        base, quote = parts[0].upper(), parts[1].upper()
        if quote not in CONFIG["quotes"]:
            continue
        if scope and base not in scope:
            continue
        vol = tickers.get(symbol, {}).get("quoteVolume", 0) or 0
        prev = by_base.get(base)
        if prev is None or vol > prev[1]:
            by_base[base] = (symbol, vol)

    pairs = sorted(by_base.values(), key=lambda t: t[1], reverse=True)
    return [symbol for symbol, _ in pairs]


def build_symbol_details(r, candles, hist_tab):
    """Detaliile complete ale unui simbol pentru dashboard: indicatori, structura,
    Fibonacci, plan, prognoza, lumanari pentru grafic, Elliott, lichiditate si
    lichidari - ACELASI calcul pe orice bursa. Doar CPU, zero apeluri API.

    `r` e rezultatul scorarii (cu persistenta), `candles` seria INCHISA a simbolului,
    `hist_tab` istoricul masurat pentru prognoza (plan_tracker.history_table)."""
    d_highs = [c[2] for c in candles]
    d_lows = [c[3] for c in candles]
    d_closes = [c[4] for c in candles]
    d_struct = compute_structure_levels(d_highs, d_lows)
    d_fib = compute_fibonacci(d_highs, d_lows)
    # Elliott calculat o singura data per token, refolosit mai jos.
    _ew_tok = ew_mod.analyze([c[2] for c in candles], [c[3] for c in candles],
                             d_closes, r["price"])
    # FEREASTRA ADAPTIVA: se largeste pana la primul punct al numaratorii
    # principale. Cu 90 de bare fixe, structura putea cadea complet in afara
    # graficului - masurat: 0 din 4 puncte vizibile, iar proiectia aparea
    # fara undele din care provine. Plafonat la CHART_BARS_MAX ca pagina sa
    # ramana usoara.
    _pri_idx = [pt["idx"] for pt in ((_ew_tok.get("primary") or {}).get("points") or [])
                if pt.get("idx") is not None]
    _nb = CHART_BARS
    if _pri_idx:
        _nb = max(CHART_BARS, min(len(candles) - min(_pri_idx) + 8, CHART_BARS_MAX))
    _nb = min(_nb, len(candles))

    _plan_tok = compute_trade_plan(r["direction"], r["price"], r["atr"], d_struct, d_fib)
    return {
        "direction": r["direction"],
        "score": r["risk_adjusted"],
        "probability": r["probability"],
        "components": r["components"],
        "price": r["price"],
        "atr": r["atr"],
        "persistence": r["persistence"],
        "age_minutes": r["age_minutes"],
        "indicators": indicators.compute_all(candles),
        "structure": d_struct,
        "fibonacci": d_fib,
        "plan": _plan_tok,
        # PROGNOZA: linie continua prin pretul real pana acum, apoi punctata
        # din prezent - scenariul Elliott ramas sau drumul planului, cu
        # durata si probabilitatea din istoric.
        "forecast": ew_mod.forecast_path(
            _ew_tok.get("primary"), [c[2] for c in candles], [c[3] for c in candles],
            d_closes, plan=_plan_tok,
            hist=hist_tab.get(f"{r['direction']}:{int(r['risk_adjusted'] // 20) * 20}"),
            plan_dir=r["direction"], agg_bias=ew_mod.bias(_ew_tok, r["direction"])),
        "sparkline": [round_price(c) for c in d_closes[-SPARKLINE_BARS:]],
        # LUMANARI pentru graficul bogat al fiecarui token cu semnal.
        # Pastrez CHART_BARS bare, rotunjite, doar OHLC + volum - suficient
        # pentru lumanari, EMA si panourile de sub grafic. Fisierul se
        # SUPRASCRIE la fiecare scanare, deci nu se acumuleaza; costa ~8 KB
        # per token, adica sub 200 KB pentru intreaga lista.
        "candles": [[c[0], round_price(c[1]), round_price(c[2]),
                     round_price(c[3]), round_price(c[4]), round(c[5] or 0, 2)]
                    for c in candles[-_nb:]],
        "ema20": [None if v is None else round_price(v)
                  for v in ema_series_full(d_closes, 20)[-_nb:]],
        "ema50": [None if v is None else round_price(v)
                  for v in ema_series_full(d_closes, 50)[-_nb:]],
        # Structura de piata per simbol. FARA multi-timeframe: ar insemna
        # 28 x 3 apeluri in plus la fiecare scanare. Timeframe-urile de
        # confirmare se descarca doar pentru simbolul afisat pe graficul
        # principal, unde chiar sunt privite.
        "liq_structure": ls_mod.build([c[2] for c in candles],
                                      [c[3] for c in candles], d_closes,
                                      r["atr"], r["price"], CONFIG["timeframe"]),
        # `offset` aliniaza indicii punctelor (calculati pe seria completa)
        # cu cele CHART_BARS lumanari pastrate pentru grafic. Fara el,
        # punctele cele mai VECHI erau desenate peste barele cele mai NOI.
        "elliott": {**_ew_tok, "offset": max(0, len(candles) - _nb)},
        "structure_panel": struct_mod.build(
            d_closes, [c[2] for c in candles], [c[3] for c in candles],
            r["atr"], base_tf=CONFIG["timeframe"], price=r["price"]),
        # harta de lichidari si pentru simbolurile din detalii, nu doar
        # pentru cel mai bun candidat - dashboard-ul le arata pe toate
        "liquidation": (lambda mp, bs: {"above": mp.get("above"),
                                        "below": mp.get("below"), "bias": bs,
                                        "oi_scaled": mp.get("oi_scaled")})(
            *(lambda mp: (mp, liq_mod.magnet_bias(mp, r["price"], r["direction"])))(
                liq_mod.build_map(candles, r["price"]))),
    }


def build_signal_context(sig, candles, exchange, caps, book_levels, alt_state):
    """Evidentele complete ale unui semnal - aceleasi pe orice bursa - si nivelurile
    planului. Intoarce (niveluri, semnal imbogatit).

    `exchange` e conexiunea bursei semnalului (order flow, open interest, timeframe-
    urile de confirmare), `caps` capabilitatile ei, `book_levels` order book-ul
    ACESTUI simbol (fetch_liquidity_levels) sau None.
    REGULA (garda: check_integrity): totul se calculeaza DOAR din seria proprie -
    highs_s / lows_s / closes_s - niciodata din seria altui token."""
    highs_s = [c[2] for c in candles]
    lows_s = [c[3] for c in candles]
    closes_s = [c[4] for c in candles]
    struct_s = compute_structure_levels(highs_s, lows_s)
    fib_s = compute_fibonacci(highs_s, lows_s)
    levels = compute_trade_plan(sig["direction"], sig["price"], sig["atr"], struct_s, fib_s)

    # EVIDENTE: din OHLCV-ul deja descarcat, deci zero apeluri API in plus.
    # Acelasi obiect alimenteaza si agentul (ca vector orientat) si
    # dashboard-ul (ca lista citibila) - o singura sursa de adevar.
    # ATENTIE: in acest bloc se folosesc DOAR highs_s / lows_s / closes_s.
    # Seria de inchideri din exterior (a candidatului principal) calcula Ichimoku,
    # regimul, Elliott si lichiditatea cu maximele unui token si inchiderile
    # altuia - pe dashboard, NEAR aparea "SUB NOR" desi era peste, iar
    # agentul invata din caracteristici corupte. Garda: check_integrity.
    sig_ind = indicators.compute_all(candles)
    sig_rsi = rsi(closes_s, 14)
    # Order flow si dezechilibrul cartii: exista doar daca bursa le suporta.
    # Daca lipsesc, evidentele corespunzatoare sunt pur si simplu absente -
    # nu inlocuite cu valori neutre, care ar minti modelul.
    sig_flow = ex_mod.order_flow(exchange, sig["symbol"], caps)
    sig_book = None
    if book_levels and book_levels.get("bids") and book_levels.get("asks"):
        sig_book = {"bid_volume": sum(b["amount"] for b in book_levels["bids"]),
                    "ask_volume": sum(a["amount"] for a in book_levels["asks"])}
    # HARTA DE LICHIDARI: construita din OHLCV, deci exista si in backtest.
    # Open interest o scaleaza daca bursa il ofera, dar nu e obligatoriu -
    # deciziile se iau pe densitate relativa, nu absoluta.
    sig_oi = ex_mod.open_interest(exchange, sig["symbol"], caps)
    sig_liq = liq_mod.build_map(candles, sig["price"], oi_weight=sig_oi)
    sig_liq_bias = liq_mod.magnet_bias(sig_liq, sig["price"], sig["direction"])
    # STRUCTURA DE PIATA. Timeframe-urile de confirmare se descarca o
    # singura data pentru simbolul afisat, nu pentru toate - altfel ar
    # insemna 28 x 3 apeluri in plus la fiecare scanare.
    def _confirm_closes(tf):
        if tf == CONFIG["timeframe"]:
            return closes_s
        try:
            o = exchange.fetch_ohlcv(sig["symbol"], timeframe=tf, limit=120)
        except Exception:
            return None
        if not o or len(o) < 60:
            return None
        return [c[4] for c in o[:-1]]

    sig_struct = struct_mod.build(
        closes_s, [c[2] for c in candles], [c[3] for c in candles],
        sig["atr"], base_tf=CONFIG["timeframe"],
        fetch_closes=_confirm_closes, order_book=book_levels,
        price=sig["price"])

    sig_ew = ew_mod.analyze([c[2] for c in candles], [c[3] for c in candles],
                            closes_s, sig["price"])
    sig_ew_bias = ew_mod.bias(sig_ew, sig["direction"])

    sig_liqs = ls_mod.build([c[2] for c in candles], [c[3] for c in candles],
                            closes_s, sig["atr"], sig["price"], CONFIG["timeframe"])
    sig_liqs_bias = ls_mod.bias(sig_liqs, sig["direction"])

    sig_evidence = ev_mod.build_evidence(sig_ind, sig["price"], sig["atr"],
                                         sig_rsi, sig.get("components"),
                                         flow=sig_flow, book=sig_book,
                                         caps=caps,
                                         liq=sig_liq, liq_bias=sig_liq_bias,
                                         struct=sig_struct,
                                         ew=sig_ew, ew_bias=sig_ew_bias,
                                         liqs=sig_liqs, liqs_bias=sig_liqs_bias,
                                         alt=alt_state, symbol=sig["symbol"],
                                         direction=sig["direction"])
    # CONFLICT PLAN - ELLIOTT. `sig_ew_bias` e exact caracteristica ev_elliott
    # a agentului (directia asteptata a structurii, fata de directia planului).
    # Masurat pe 16.318 planuri reale: cu ev_elliott <= -0.1 (Elliott
    # contrazice planul) R mediu +0.042, fara avantaj demonstrat (IC95 include
    # zero); fara conflict +0.112R. Diferenta +0.070R, IC95 +0.006..+0.137.
    _pr = (sig_ew or {}).get("primary") or {}
    _next = None
    if _pr.get("expected") and _pr["expected"] != sig["direction"]:
        _pp = [q["price"] for q in ((_pr.get("projection") or {}).get("path") or [])
               if q.get("projected")]
        if _pp:
            _next = min(_pp) if sig["direction"] == "LONG" else max(_pp)
    _conflict = {"bias": sig_ew_bias, "text": _pr.get("stage_text"),
                 "next_entry": _next, "headline": _pr.get("headline")}
    sig = {**sig,
           "elliott_conflict": _conflict,
           "evidence": sig_evidence,
           "fusion": ev_mod.fusion(sig_evidence, sig["direction"]),
           "indicators": sig_ind,
           "structure_panel": sig_struct,
           "elliott": sig_ew,
           "liq_structure": sig_liqs,
           "liquidation": {"above": sig_liq.get("above"),
                           "below": sig_liq.get("below"),
                           "bias": sig_liq_bias,
                           "oi_scaled": sig_liq.get("oi_scaled")},
           "components": {**(sig.get("components") or {}),
                          **ev_mod.evidence_features(sig_evidence, sig["direction"])}}
    return levels, sig


def save_json_compact(path, data):
    """Ca save_json (scriere atomica), dar fara indentare: datele modulelor per
    bursa se rescriu la fiecare scanare, iar forma compacta tine istoricul git mic."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, separators=(",", ":"))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def light_details(details):
    """Indicatorii rezumati per simbol pentru exchange_scans.json (tab-ul bursei)."""
    out = {}
    for k, v in (details or {}).items():
        ind = v.get("indicators") or {}
        vp = ind.get("volume_profile") or {}
        out[k] = {"supertrend": (ind.get("supertrend") or {}).get("direction"),
                  "vwap": ind.get("vwap"), "poc": vp.get("poc"), "vah": vp.get("vah"),
                  "val": vp.get("val"), "macd_hist": (ind.get("macd") or {}).get("histogram"),
                  "position": ind.get("price_vs_value_area")}
    return out


def proposal_record(sig, levels, decision, agent_pred, trained):
    """Propunerea de intrare, in forma afisata de modulul bursei - identica pe
    bursa activa (unde devine plan) si pe celelalte (unde e doar simulata)."""
    return {
        "symbol": sig["symbol"], "direction": sig["direction"],
        "score": sig.get("risk_adjusted"), "price": sig.get("price"), "atr": sig.get("atr"),
        "levels": levels,
        "decision": {k: (decision or {}).get(k) for k in
                     ("action", "mode", "reason", "calibrated_prob", "agent_prob", "expected_value_r")},
        "agent": {"probability": (agent_pred or {}).get("probability"),
                  "active": (agent_pred or {}).get("active"),
                  "superior": (agent_pred or {}).get("superior")},
        "neighbors": sig.get("neighbors"),
        "fusion": sig.get("fusion"),
        "evidence": sig.get("evidence") or [],
        "elliott_conflict": sig.get("elliott_conflict"),
        "trained": bool(trained),
    }


def _open_plan_for_base(plan_store, symbol, direction):
    """Planul deschis pe bursa activa pentru ACELASI token si aceeasi directie
    (perechile pot diferi intre burse: BTC/USD pe Kraken, BTC/USDT pe OKX)."""
    base = symbol.split("/")[0]
    for p in reversed((plan_store or {}).get("plans") or []):
        if (p.get("state") in (plan_tracker.STATE_PENDING, plan_tracker.STATE_OPEN, plan_tracker.STATE_TP1)
                and p.get("direction") == direction and str(p.get("symbol", "")).split("/")[0] == base):
            return {"id": p.get("id"), "symbol": p.get("symbol"), "state": p.get("state")}
    return None


def analyze_exchange(adapter, handle, card, ctx):
    """ANALIZA COMPLETA pe o bursa secundara, cu acelasi nucleu ca pe bursa activa:
    scor, detalii pe token (grafic, Elliott, structura, lichidari), evidente si
    decizia pe care ar lua-o agentul pentru semnalele de top.

    NU creeaza planuri si NU atinge memoria agentului (vezi nota de la
    SECONDARY_SCAN_LIMIT). Orice esec e o stare raportata, nu o exceptie, iar
    bugetul de timp se verifica intre apeluri: o bursa lenta se trunchiaza, nu
    intinde scanarea."""
    t0 = time.monotonic()
    deadline = t0 + ctx["budget"]
    caps = card.get("available") or [ex_mod.CAP_OHLCV]
    log = []
    out = {"id": adapter.id, "label": adapter.label, "resolved": [], "missing": [],
           "results": [], "details": {}, "proposals": {}, "truncated": False,
           "error": None, "history_entry": None, "log": log, "duration_s": 0.0}
    markets = adapter.markets(handle)
    if not markets:
        out["error"] = "pietele bursei nu au putut fi incarcate"
        return out
    tickers = adapter.tickers(handle)
    # Aceeasi selectie ca pe bursa activa: perechea cu volumul cel mai mare pentru
    # fiecare token (pe Kraken, USD bate de departe USDT).
    aliases = CONFIG.get("aliases", {})
    # O SINGURA pereche per token din watchlist: un token listat sub doua nume
    # (POL si MATIC) ar ocupa doua locuri si ar putea impinge alt token din lista de 30.
    canon = {al: b for b in (CONFIG.get("watchlist") or []) for al in aliases.get(b, [b])}
    seen, resolved = set(), []
    for s_ in build_eligible_pairs(markets, tickers, ctx["scope"]):
        c_ = canon.get(s_.split("/")[0], s_.split("/")[0])
        if c_ not in seen:
            seen.add(c_)
            resolved.append(s_)
    resolved = resolved[: ctx["limit"]]
    out["resolved"] = sorted(resolved)
    out["missing"] = [b for b in (CONFIG.get("watchlist") or [])
                      if not any(s_.split("/")[0] in aliases.get(b, [b]) for s_ in resolved)]
    cache, results = {}, []
    for sym in resolved:
        if time.monotonic() > deadline:
            out["truncated"] = True
            log.append(f"buget de timp atins dupa {len(cache)} din {len(resolved)} simboluri")
            break
        try:
            ohlcv = handle.fetch_ohlcv(sym, timeframe=CONFIG["timeframe"], limit=CONFIG["candles"])
        except Exception as e:
            log.append(f"{sym}: {str(e)[:120]}")
            continue
        if len(ohlcv) > 1:
            ohlcv = ohlcv[:-1]          # aceeasi regula: fara lumanarea neinchisa
        cache[sym] = ohlcv
        scored = score_symbol(ohlcv, ctx["weights"])
        if not scored:
            continue
        persistence, age_minutes = compute_persistence_and_age(
            ctx["history"], sym, scored["direction"], ctx["now_ts"])
        results.append({"symbol": sym, "persistence": persistence, "age_minutes": age_minutes, **scored})
    if resolved and not cache:
        # nicio serie descarcata (bursa nu raspunde la lumanari sau bugetul s-a terminat
        # inainte de primul simbol): modulul nu are voie sa se goleasca - datele
        # anterioare raman, marcate vechi, cu motivul
        out["error"] = ("bugetul de timp s-a terminat inainte de primul simbol" if out["truncated"]
                        else f"nicio serie de lumanari descarcata din {len(resolved)} simboluri")
        out["duration_s"] = round(time.monotonic() - t0, 1)
        return out
    for r in results:
        out["details"][r["symbol"]] = build_symbol_details(r, cache[r["symbol"]], ctx["hist_tab"])
    results.sort(key=lambda r: -r["risk_adjusted"])
    out["results"] = results
    top = ([r for r in results if r["direction"] == "LONG"][: CONFIG["top_n_per_direction"]]
           + [r for r in results if r["direction"] == "SHORT"][: CONFIG["top_n_per_direction"]])
    for sig in top:
        if time.monotonic() > deadline:
            out["truncated"] = True
            log.append(f"buget de timp atins la propuneri ({len(out['proposals'])} din {len(top)})")
            break
        book = (fetch_liquidity_levels(handle, sig["symbol"], attempts=adapter.book_limits)
                if ex_mod.CAP_ORDERBOOK_LIVE in caps else None)
        levels, sig_e = build_signal_context(sig, cache[sig["symbol"]], handle, caps, book,
                                             ctx["alt_state"])
        if not levels:
            continue
        sig_e["neighbors"] = ai_agent.comparable_entries(ai_agent.extract_features(sig_e), ctx["closed"])
        agent_pred = ai_agent.predict_for_signal(ctx["agent_model"], ctx["agent_state"], sig_e)
        sig_e = {**sig_e, "bar_seconds": timeframe_seconds()}
        decision = plan_tracker.decide(ctx["calibration"], sig_e, agent_pred)
        rec = proposal_record(sig_e, levels, decision, agent_pred, trained=False)
        rec["learning_open_plan"] = _open_plan_for_base(ctx["plan_store"], sig["symbol"], sig["direction"])
        out["proposals"][sig["symbol"]] = rec
    out["history_entry"] = {"scan_id_ts": ctx["now_ts"],
                            "results": [{"symbol": r["symbol"], "direction": r["direction"]} for r in results]}
    out["duration_s"] = round(time.monotonic() - t0, 1)
    return out


def _analyze_safe(adapter, handle, card, ctx):
    try:
        return analyze_exchange(adapter, handle, card, ctx)
    except Exception as e:
        return {"id": adapter.id, "label": adapter.label, "error": f"{type(e).__name__}: {str(e)[:160]}",
                "resolved": [], "missing": [], "results": [], "details": {}, "proposals": {},
                "truncated": False, "history_entry": None, "log": [], "duration_s": 0.0}


def run_exchange_modules(exchange_cards, exchange_handles, primary_id, ctx):
    """Analiza completa pe fiecare bursa secundara conectata, IN PARALEL (fiecare cu
    bugetul ei, pe conexiunea deja deschisa la sondare), apoi datele fiecarui modul
    in data/exchanges/<id>/. Intoarce {id: rezumat} pentru exchange_scans.json.

    La un esec total al unei burse, detaliile anterioare raman pe disc, iar
    rezumatul poarta eroarea: dashboard-ul afiseaza atunci datele ca vechi, cu
    motivul - nu le prezinta drept actuale si nici nu goleste modulul."""
    jobs = []
    for card in exchange_cards:
        eid = card["id"]
        if eid == primary_id or not card.get("connected") or eid not in exchange_handles:
            continue
        hist = load_json(os.path.join(EXCHANGES_DIR, eid, "history.json"), [])
        jobs.append((ex_mod.adapter(eid), exchange_handles[eid], card, {**ctx, "history": hist}))
    if not jobs:
        return {}
    print(f"\nModule per bursa: analiza completa pe {len(jobs)} burse, in paralel "
          f"(buget {ctx['budget']}s fiecare)")
    with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        futures = [pool.submit(_analyze_safe, *job) for job in jobs]
        outs = [f.result() for f in futures]
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    summaries = {}
    for (adapter, _h, card, jctx), res in zip(jobs, outs):
        eid = adapter.id
        folder = os.path.join(EXCHANGES_DIR, eid)
        ok = not res.get("error")
        if ok:
            save_json_compact(os.path.join(folder, "details.json"),
                              {"scan_time": stamp, "timeframe": CONFIG["timeframe"], "exchange": eid,
                               "label": adapter.label, "trained": False, "symbols": res["details"]})
            save_json_compact(os.path.join(folder, "proposals.json"),
                              {"scan_time": stamp, "exchange": eid, "trained": False,
                               "learning_exchange": primary_id, "proposals": res["proposals"]})
            if res.get("history_entry"):
                save_json_compact(os.path.join(folder, "history.json"),
                                  (jctx["history"] + [res["history_entry"]])[-EXCHANGE_HISTORY_KEEP:])
        summaries[eid] = {
            "resolved": res["resolved"], "missing": res["missing"],
            "results": [{"symbol": r["symbol"], "direction": r["direction"], "score": r["risk_adjusted"],
                         "price": r["price"], "atr": r["atr"], "components": r["components"]}
                        for r in res["results"]],
            "details": light_details(res["details"]),
            "truncated": res["truncated"], "error": res["error"], "primary": False,
            "analysis": "completa", "proposals": len(res["proposals"]),
            "duration_s": res["duration_s"], "scan_time": stamp if ok else None,
        }
        print(f"  [{eid}] {len(res['results'])} semnale din {len(res['resolved'])} simboluri, "
              f"{len(res['proposals'])} propuneri, {res['duration_s']}s"
              + ("  (trunchiat)" if res["truncated"] else "")
              + (f"  EROARE: {res['error']}" if res["error"] else ""))
        for line in res.get("log", [])[:6]:
            print(f"      {line}")
    return summaries


def probe_all_exchanges(scope):
    """Sondeaza TOATE bursele din lista, nu doar pana la prima care merge.

    Costa cateva secunde in plus, dar dashboard-ul are nevoie de starea fiecareia
    ca sa poata arata un tab per bursa, inclusiv pentru cele care nu raspund.
    Fisele se salveaza si se folosesc si la alegerea bursei de lucru.
    """
    cards = []
    # Sondez tot registrul, nu doar lantul de fallback: dashboard-ul trebuie sa
    # arate un tab si pentru bursele care nu sunt candidate de lucru dar au
    # capabilitati relevante (ex. Bybit, singura cu arhive de order book).
    # Ordinea de fallback ramane prima, ca alegerea sa fie determinista.
    order = CONFIG["exchange_fallback"] + [e for e in ex_mod.DEFAULT_ORDER
                                           if e not in CONFIG["exchange_fallback"]]
    handles = {}
    for eid in order:
        card, ex = ex_mod.probe_exchange(ccxt, eid)
        cards.append(card)
        if ex is not None and card["connected"]:
            # pastrez conexiunea: scanarea de afisare o refoloseste, ca sa nu
            # platesc inca o data load_markets pentru fiecare bursa
            handles[eid] = ex
        status = "conectat" if card["connected"] else f"esuat: {card['error']}"
        caps = ",".join(card["available"]) or "-"
        print(f"  [{eid}] {status} | capabilitati: {caps}")
    return cards, handles


def connect_exchange(scope):
    """Alege exchange-ul dupa ACOPERIRE, nu doar dupa conectivitate.

    Varianta veche lua primul exchange care raspundea - a nimerit Kraken, care
    a mers, dar acopera putin din top-200. Acum, pentru fiecare exchange care
    raspunde, calculez cate simboluri din scope gaseste efectiv si ma opresc la
    primul care trece pragul; daca niciunul nu-l trece, folosesc cel mai bun
    gasit (tot mai bine decat sa pic)."""
    best = None
    last_error = None

    for exchange_id in CONFIG["exchange_fallback"]:
        exchange_class = getattr(ccxt, exchange_id, None)
        if exchange_class is None:
            print(f"[!] '{exchange_id}' nu exista in ccxt, sar peste.")
            continue
        exchange = exchange_class({"enableRateLimit": True})
        try:
            markets = exchange.load_markets()
            tickers = exchange.fetch_tickers()
        except Exception as e:
            print(f"[!] {exchange_id} indisponibil din acest runner: {e}")
            last_error = e
            continue

        pairs = build_eligible_pairs(markets, tickers, scope)
        print(f"[OK] {exchange_id}: {len(markets)} piete -> {len(pairs)} simboluri eligibile din scope.")

        if best is None or len(pairs) > len(best[3]):
            best = (exchange, markets, tickers, pairs, exchange_id)

        if len(pairs) >= CONFIG["min_universe"]:
            print(f"=> Folosesc {exchange_id} (acoperire suficienta).")
            return best

    if best is None:
        raise SystemExit(
            f"[EROARE FATALA] Niciun exchange din {CONFIG['exchange_fallback']} nu "
            f"a raspuns din acest runner. Ultima eroare: {last_error}\n"
            "Adauga alt exchange in CONFIG['exchange_fallback'], sau ruleaza "
            "scriptul de pe un server/PC/telefon cu IP rezidential (nu de cloud)."
        )

    print(f"[!] Niciun exchange nu atinge pragul de {CONFIG['min_universe']} simboluri. "
          f"Folosesc cel mai bun gasit: {best[4]} cu {len(best[3])} simboluri.")
    return best


def main():
    watchlist = CONFIG.get("watchlist") or []
    if watchlist:
        # pragul de acoperire nu poate depasi cate simboluri exista in watchlist
        CONFIG["min_universe"] = max(1, int(len(watchlist) * 0.7))
        # Extind fiecare simbol cu aliasurile lui, ca sa nu ratez perechea din
        # cauza unei redenumiri (ex. TON -> GRAM).
        coingecko_scope = set()
        for sym in watchlist:
            coingecko_scope.update(CONFIG.get("aliases", {}).get(sym, [sym]))
        print(f"Watchlist activa: {len(watchlist)} simboluri "
              f"({len(coingecko_scope)} incluzand aliasuri) - ignor top-200 CoinGecko.")
    else:
        coingecko_scope = fetch_coingecko_top_symbols(CONFIG["coingecko_scope"])
        if not coingecko_scope:
            print("[!] Nu am putut lua lista CoinGecko - continui fara filtrul de scope.")

    # Sondez TOATE bursele: dashboard-ul are nevoie de starea fiecareia pentru
    # tab-uri, inclusiv pentru cele care nu raspund.
    exchange_cards, exchange_handles = probe_all_exchanges(coingecko_scope)

    exchange, markets, all_tickers, eligible, exchange_id = connect_exchange(coingecko_scope)

    # Fixez semnatura de capabilitati INAINTE de a crea orice plan. Geometria
    # trebuie sa reflecte ce a oferit efectiv bursa, nu implicitul din mediu.
    active_card = next((c for c in exchange_cards if c["id"] == exchange_id), None)
    active_caps = (active_card or {}).get("available") or [ex_mod.CAP_OHLCV]
    caps_sig = ex_mod.capability_signature(active_caps)
    plan_tracker.set_capabilities(caps_sig)
    print(f"Capabilitati active pe {exchange_id}: {','.join(active_caps)} "
          f"-> geometria {plan_tracker.GEOMETRY_VERSION}")

    # Capabilitatile bursei ALESE decid ce evidente se pot calcula si intra in
    # semnatura geometriei. Fara pasul asta, order flow-ul nu ar aparea niciodata
    # chiar daca bursa il suporta, iar semnatura ar ramane blocata pe "o".
    active_caps = next((c["available"] for c in exchange_cards
                        if c["id"] == exchange_id and c["connected"]), [ex_mod.CAP_OHLCV])
    active_sig = ex_mod.capability_signature(active_caps)
    if os.environ.get("SCAN_CAPS") != active_sig:
        print(f"[i] Capabilitati active pe {exchange_id}: {','.join(active_caps)} "
              f"-> semnatura '{active_sig}'")
        print(f"    Geometria e {plan_tracker.GEOMETRY_VERSION}. Daca semnatura difera, "
              f"seteaza SCAN_CAPS={active_sig} in workflow ca planurile sa fie "
              f"grupate corect la invatare.")
    save_json(EXCHANGES_FILE, {"exchanges": exchange_cards, "used": exchange_id,
                               "active_signature": active_sig,
                               "geometry": plan_tracker.GEOMETRY_VERSION})
    universe = eligible[: CONFIG["universe_size"]]
    print(f"Universe final: {len(universe)} simboluri pe {exchange_id}.")

    weights = load_json(WEIGHTS_FILE, dict(DEFAULT_WEIGHTS))
    history = load_json(HISTORY_FILE, [])

    # 1) evalueaza semnalele vechi si "invata" din ele
    weights = evaluate_and_learn(
        history, weights, all_tickers,
        CONFIG["lookahead_hours"], CONFIG["hit_threshold_atr"],
    )

    # 2) scaneaza piata curenta
    now_ts = time.time()
    results = []
    ohlcv_cache = {}
    for symbol in universe:
        try:
            ohlcv = exchange.fetch_ohlcv(symbol, timeframe=CONFIG["timeframe"], limit=CONFIG["candles"])
        except Exception as e:
            print(f"[!] {symbol}: {e}")
            continue
        # Renunt la ULTIMA lumanare: e cea curenta, inca neinchisa.
        # De ce conteaza: scanarea porneste la minute imprevizibile (cron e :07,
        # dar am masurat rulari intre :09 si :59 din cauza intarzierilor GitHub),
        # deci bara curenta e prinsa oriunde intre 8% si 92% formata. EMA, RSI si
        # ATR calculate pe ea se schimba pana la inchidere - acelasi setup da
        # scoruri diferite doar in functie de cat de tarziu a pornit jobul.
        # In plus, backtest.py foloseste doar bare inchise; fara acest fix cele
        # doua nu testeaza acelasi lucru si rezultatele nu sunt comparabile.
        if len(ohlcv) > 1:
            ohlcv = ohlcv[:-1]
        ohlcv_cache[symbol] = ohlcv
        scored = score_symbol(ohlcv, weights)
        if not scored:
            continue
        persistence, age_minutes = compute_persistence_and_age(history, symbol, scored["direction"], now_ts)
        results.append({"symbol": symbol, "persistence": persistence, "age_minutes": age_minutes, **scored})

    # FAZA CICLULUI ALTCOIN SEASON, evaluata la fiecare scanare pe date reale
    # (CoinGecko + lumanari zilnice de pe exchange). Nu opreste niciodata
    # scanarea: la o problema de date pastreaza ultima evaluare.
    try:
        alt_state = alt_mod.update(exchange, results)
    except Exception as _e:
        print(f"[!] altseason: {_e}")
        alt_state = None

    longs = sorted([r for r in results if r["direction"] == "LONG"], key=lambda r: r["risk_adjusted"], reverse=True)
    shorts = sorted([r for r in results if r["direction"] == "SHORT"], key=lambda r: r["risk_adjusted"], reverse=True)
    best = max(results, key=lambda r: r["risk_adjusted"]) if results else None

    # 3) analiza detaliata (structura + fibonacci + plan SL/TP) pentru
    # cel mai bun candidat, plus datele de grafic pentru dashboard
    deep_analysis = None
    # ---- DETALII PER SIMBOL, pentru dashboard.
    # Se calculeaza din ohlcv_cache, deci ZERO apeluri API in plus - doar CPU.
    # Fisierul se SUPRASCRIE la fiecare rulare, nu se acumuleaza: un instantaneu
    # al starii curente. Daca as fi salvat lumanarile complete pentru toate
    # simbolurile ar fi insemnat ~326 KB pe scanare, comise orar - peste 200 MB
    # pe luna in git. Pastrez in schimb doar indicatorii (cateva numere) si o
    # linie de pret scurta pentru graficul mic.
    details = {}
    # ISTORICUL MASURAT pentru prognoza de pe grafic: rata de castig si durata
    # mediana pe (directie, interval de scor), din planurile inchise ale
    # familiei. Citire separata - planurile se incarca in flux abia mai jos.
    try:
        _hist_tab = plan_tracker.history_table(plan_tracker.load_plans())
    except Exception as _e:
        print(f"[!] istoric indisponibil pentru prognoza: {_e}")
        _hist_tab = {}

    for r in results:
        candles = ohlcv_cache.get(r["symbol"])
        if not candles:
            continue
        details[r["symbol"]] = build_symbol_details(r, candles, _hist_tab)
    save_json(DETAILS_FILE, {"scan_time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
                              "timeframe": CONFIG["timeframe"],
                             "exchange": exchange_id, "symbols": details})

    # SCANARE PER BURSA, doar pentru afisare. Bursa activa refoloseste datele
    # deja descarcate, deci nu costa nimic in plus; celelalte se scaneaza in
    # limita de timp, ca sa nu intinda rularea.
    scans = {}
    if exchange_id:
        scans[exchange_id] = {
            "resolved": sorted(ohlcv_cache.keys()),
            "missing": [b for b in (CONFIG.get("watchlist") or [])
                        if not any(s_.split("/")[0] in
                                   CONFIG.get("aliases", {}).get(b, [b])
                                   for s_ in ohlcv_cache)],
            "results": [{"symbol": r["symbol"], "direction": r["direction"],
                         "score": r["risk_adjusted"], "price": r["price"],
                         "atr": r["atr"], "components": r["components"]}
                        for r in sorted(results, key=lambda r: -r["risk_adjusted"])],
            "details": {k: {"supertrend": (v.get("indicators") or {}).get("supertrend", {}).get("direction"),
                            "vwap": (v.get("indicators") or {}).get("vwap"),
                            "poc": ((v.get("indicators") or {}).get("volume_profile") or {}).get("poc"),
                            "vah": ((v.get("indicators") or {}).get("volume_profile") or {}).get("vah"),
                            "val": ((v.get("indicators") or {}).get("volume_profile") or {}).get("val"),
                            "macd_hist": ((v.get("indicators") or {}).get("macd") or {}).get("histogram"),
                            "position": (v.get("indicators") or {}).get("price_vs_value_area")}
                        for k, v in details.items()},
            "truncated": False, "error": None, "primary": True,
        }

    # ---- PLANURI: creez pentru toate semnalele din top, nu doar pentru cel
    # mai bun. Reutilizez ohlcv_cache, deci in mod normal nu costa apeluri
    # API in plus.
    plan_store = plan_tracker.load_plans()

    # 0) migrare automata: inchide planurile ramase din geometrii vechi, ca sa
    # nu blocheze combinatiile simbol+directie. Ruleaza o singura data efectiv.
    migrated = plan_tracker.auto_migrate_geometry(plan_store)
    if migrated:
        print(f"\nMigrare geometrie: am inchis {len(migrated)} planuri vechi "
              f"(deblocheaza simbolurile pentru planuri noi):")
        for pid, sym, direction, prev in migrated[:8]:
            print(f"  PLAN #{pid} {sym} {direction} (era {prev})")
        if len(migrated) > 8:
            print(f"  ... si inca {len(migrated) - 8}")

    if best:
        best_ohlcv = ohlcv_cache[best["symbol"]]
        highs = [c[2] for c in best_ohlcv]
        lows = [c[3] for c in best_ohlcv]
        closes = [c[4] for c in best_ohlcv]

        structure = compute_structure_levels(highs, lows)
        fib = compute_fibonacci(highs, lows)
        plan = compute_trade_plan(best["direction"], best["price"], best["atr"], structure, fib)
        liquidity = fetch_liquidity_levels(exchange, best["symbol"])
        # indicatorii din poze - calculati din OHLCV deja descarcat, zero apeluri API in plus
        inds = indicators.compute_all(best_ohlcv)
        deep_analysis = {"structure": structure, "fibonacci": fib, "plan": plan,
                         "liquidity": liquidity, "indicators": inds}

        n = CONFIG["chart_candles"]
        # GRAFIC IMBOGATIT: tot ce se desena in sistemul de referinta exista deja
        # calculat aici - nivelurile planului, VWAP, POC/VAH/VAL, SuperTrend,
        # MACD, RSI. Pana acum ajungeau doar in carduri de text. Le salvez ca sa
        # poata fi desenate ca linii etichetate peste lumanari.
        best_ind = indicators.compute_all(best_ohlcv)
        best_struct = compute_structure_levels(
            [c[2] for c in best_ohlcv], [c[3] for c in best_ohlcv])
        best_plan = compute_trade_plan(best["direction"], best["price"], best["atr"],
                                       best_struct, fib)
        # Planul INGHETAT pentru acest simbol, daca exista unul deschis. Asta e
        # distinctia "LOCKED vs CURRENT" din poze: ce s-a decis atunci, langa
        # ce ar rezulta acum.
        locked = None
        for pl_ in reversed(plan_store.get("plans") or []):
            if (pl_.get("symbol") == best["symbol"]
                    and pl_.get("state") in (plan_tracker.STATE_PENDING,
                                             plan_tracker.STATE_OPEN,
                                             plan_tracker.STATE_TP1)):
                locked = {"id": pl_["id"], "direction": pl_["direction"],
                          "entry": pl_["entry"], "sl": pl_["sl"],
                          "tp1": pl_["tp1"], "tp2": pl_["tp2"],
                          "state": pl_.get("state_detail") or pl_.get("state")}
                break

        def _tail(series):
            return [None if v is None else round_price(v) for v in series[-n:]]

        rsi_series = []
        for i in range(len(closes)):
            rsi_series.append(rsi(closes[:i + 1], 14) if i >= 14 else None)

        # Largesc fereastra pana la primul punct al numaratorii principale,
        # plus o marja, marginit la cate bare exista si la un maxim rezonabil.
        _ew_full = ew_mod.analyze([c[2] for c in best_ohlcv],
                                  [c[3] for c in best_ohlcv], closes, best["price"])
        _pri = _ew_full.get("primary") or {}
        _idxs = [pt.get("idx") for pt in (_pri.get("points") or [])
                 if pt.get("idx") is not None]
        if _idxs:
            _need = len(best_ohlcv) - min(_idxs) + 12
            n = max(n, min(_need, len(best_ohlcv), 260))

        save_json(CHART_FILE, {
            "symbol": best["symbol"],
            "direction": best["direction"],
            "candles": best_ohlcv[-n:],
            "ema9": _tail(ema_series_full(closes, 9)),
            "ema20": _tail(ema_series_full(closes, 20)),
            "ema50": _tail(ema_series_full(closes, 50)),
            "ema200": _tail(ema_series_full(closes, 200)),
            "rsi": _tail(rsi_series),
            "macd": best_ind.get("macd"),
            "indicators": {
                "vwap": best_ind.get("vwap"),
                "poc": (best_ind.get("volume_profile") or {}).get("poc"),
                "vah": (best_ind.get("volume_profile") or {}).get("vah"),
                "val": (best_ind.get("volume_profile") or {}).get("val"),
                "supertrend": best_ind.get("supertrend"),
            },
            "current": best_plan,
            "locked": locked,
            "forecast": ew_mod.forecast_path(
                (_ew_full or {}).get("primary"), [c[2] for c in best_ohlcv],
                [c[3] for c in best_ohlcv], closes, plan=best_plan,
                hist=_hist_tab.get(f"{best['direction']}:{int(best['risk_adjusted'] // 20) * 20}"),
                plan_dir=best["direction"], agg_bias=ew_mod.bias(_ew_full, best["direction"])),
            # ELLIOTT pentru grafic: punctele undelor cu indicii lor de bara,
            # ca sa poata fi desenate exact peste lumanarile corespunzatoare.
            # `idx` e pozitia in seria COMPLETA, iar graficul afiseaza doar
            # ultimele n bare - deci offset-ul se aplica la desenare.
            # Fereastra graficului se LARGESTE ca sa cuprinda structura Elliott
            # principala. Altfel primele unde (MAJOR START, W1, W2) cad in afara
            # ferestrei si se vad doar ultimele doua puncte - inutil, fiindca
            # tocmai relatia dintre unde e informatia.
            "elliott": (lambda r: {
                "counts": r.get("counts", [])[:3],
                "primary": r.get("primary"),
                "alive": r.get("alive"), "total": r.get("total"),
                "offset": max(0, len(best_ohlcv) - n)})(_ew_full),
            # Clusterele de lichidare pentru graficul principal: se deseneaza ca
            # benzi orizontale cu intensitate, echivalentul vizual al heatmap-ului.
            # Lichiditatea structurala lipsea din graficul principal - ajungea
            # doar in detaliile per token, deci componenta "Lichiditate" a
            # graficului principal era mereu goala.
            "liq_structure": ls_mod.build([c[2] for c in best_ohlcv],
                                          [c[3] for c in best_ohlcv], closes,
                                          best["atr"], best["price"],
                                          CONFIG["timeframe"]),
            "liquidation": (lambda mp: {
                "clusters": mp.get("clusters", [])[:16],
                "above": mp.get("above"), "below": mp.get("below"),
                "bias": liq_mod.magnet_bias(mp, best["price"], best["direction"]),
                "oi_scaled": mp.get("oi_scaled")})(
                    liq_mod.build_map(best_ohlcv, best["price"])),
            "structure": best_struct,
            "timeframe": CONFIG["timeframe"],
        })

    # 1) evaluez planurile deschise pe lumanarile proaspete
    closed_now = []
    for p in plan_store["plans"]:
        if p["state"] in plan_tracker.CLOSED_STATES:
            continue
        candles = ohlcv_cache.get(p["symbol"])
        if not candles:
            # Planul e "orfan": simbolul a iesit din top-200 sau din universul
            # scanat. Fara asta ar ramane OPEN la nesfarsit si nu s-ar invata
            # niciodata din el. Descarc explicit - sunt putine cazuri.
            try:
                candles = exchange.fetch_ohlcv(
                    p["symbol"], timeframe=CONFIG["timeframe"], limit=CONFIG["candles"])
                ohlcv_cache[p["symbol"]] = candles
                print(f"  (plan orfan #{p['id']} {p['symbol']}: descarcat separat)")
            except Exception as e:
                print(f"  [!] plan orfan #{p['id']} {p['symbol']}: {e}")
                continue
        if plan_tracker.evaluate_plan(p, candles) and p["state"] in plan_tracker.CLOSED_STATES:
            closed_now.append(p)

    # 2) recalibrez ACUM, dupa evaluare - deciziile de mai jos trebuie sa
    # foloseasca si rezultatele inchise chiar in aceasta rulare, nu date vechi
    calibration = plan_tracker.build_calibration(plan_store)

    # 3) decid daca deschid planuri noi - cu contributia agentului daca e ACTIVE
    agent_model, agent_state = ai_agent.load_agent()
    closed_for_neighbors = [p for p in plan_store["plans"]
                            if p.get("realized_r") is not None
                            and plan_tracker.same_family(p.get("geometry"))
                            and p.get("state") != plan_tracker.STATE_NO_ENTRY]
    issued, skipped = [], []
    decisions_out = {}          # decizia pentru fiecare semnal - citita de dashboard
    proposals_out = {}          # propunerea completa (evidente, vecini) - modulul bursei
    for sig in (longs[: CONFIG["top_n_per_direction"]] + shorts[: CONFIG["top_n_per_direction"]]):
        if plan_tracker.has_open_plan(plan_store, sig["symbol"], sig["direction"]):
            proposals_out[sig["symbol"]] = {"symbol": sig["symbol"], "direction": sig["direction"],
                                            "score": sig.get("risk_adjusted"), "open_plan": True,
                                            "trained": True}
            continue
        candles = ohlcv_cache.get(sig["symbol"])
        if not candles:
            continue
        # order book-ul ACESTUI simbol (vezi PER_SIGNAL_ORDER_BOOK)
        book_levels = liquidity
        if PER_SIGNAL_ORDER_BOOK and sig["symbol"] != best["symbol"]:
            book_levels = fetch_liquidity_levels(exchange, sig["symbol"])
        levels, sig = build_signal_context(sig, candles, exchange, active_caps, book_levels, alt_state)
        if not levels:
            # geometrie degenerata (ex. ATR efectiv zero) - sar peste simbol,
            # nu opresc scanarea din cauza unuia singur
            print(f"  [!] {sig['symbol']}: niveluri invalide, sar peste")
            continue

        # Verdictul planurilor comparabile: se calculeaza din memoria acumulata
        # si se salveaza pe plan, ca sa apara in dashboard exact asa cum a fost
        # la momentul deciziei - nu recalculat mai tarziu, cu alte date.
        sig["neighbors"] = ai_agent.comparable_entries(
            ai_agent.extract_features(sig), closed_for_neighbors)
        agent_pred = ai_agent.predict_for_signal(agent_model, agent_state, sig)
        sig = {**sig, "bar_seconds": timeframe_seconds()}
        decision = plan_tracker.decide(calibration, sig, agent_pred)
        decisions_out[sig["symbol"]] = {
            "action": decision["action"], "mode": decision.get("mode"),
            "reason": decision.get("reason"),
            "calibrated_prob": decision.get("calibrated_prob"),
            "agent_prob": decision.get("agent_prob"),
            "elliott_bias": (sig.get("elliott_conflict") or {}).get("bias"),
            "next_entry": (sig.get("elliott_conflict") or {}).get("next_entry")}
        proposals_out[sig["symbol"]] = proposal_record(sig, levels, decision, agent_pred, trained=True)
        if decision["action"] == "SKIP":
            skipped.append((sig["symbol"], decision["reason"]))
            continue
        new_plan = plan_tracker.create_plan(plan_store, sig, levels, decision)
        if new_plan:
            issued.append(new_plan)

    save_json(os.path.join(os.path.dirname(DETAILS_FILE), "decisions.json"),
              {"scan_time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
               "decisions": decisions_out})

    save_json_compact(os.path.join(EXCHANGES_DIR, exchange_id, "proposals.json"),
                      {"scan_time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
                       "exchange": exchange_id, "trained": True, "learning_exchange": exchange_id,
                       "proposals": proposals_out})

    # 4) salvez calibrarea finala si rezumatul
    plan_store["calibration"] = plan_tracker.build_calibration(plan_store)
    plan_store["summary"] = plan_tracker.summarize(plan_store)
    plan_tracker.save_plans(plan_store)

    print(f"\nPlanuri: {len(issued)} deschise, {len(skipped)} refuzate, "
          f"{len(closed_now)} inchise in aceasta rulare")
    for p in closed_now:
        print(f"  PLAN #{p['id']} {p['symbol']} {p['direction']}: "
              f"{p['state_detail']} -> {p['realized_r']:+.2f}R")
    for sym, reason in skipped:
        print(f"  REFUZAT {sym}: {reason}")
    plan_tracker.print_summary(plan_store)

    scan_record = {
        "scan_id_ts": now_ts,
        "scan_time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "universe_size": len(universe),
        "results": results,
        "top_long": longs[: CONFIG["top_n_per_direction"]],
        "top_short": shorts[: CONFIG["top_n_per_direction"]],
        "best_candidate": best,
        "deep_analysis": deep_analysis,
        "evaluated": False,
    }
    history.append(scan_record)

    save_json(WEIGHTS_FILE, weights)
    save_json(HISTORY_FILE, history)

    weights_history = load_json(WEIGHTS_HISTORY_FILE, [])
    weights_history.append({"ts": now_ts, "time": scan_record["scan_time"], **weights})
    save_json(WEIGHTS_HISTORY_FILE, weights_history)

    msg = format_message(scan_record)
    print(msg)
    send_telegram(CONFIG["telegram_bot_token"], CONFIG["telegram_chat_id"], msg)

    # 5) MODULELE PER BURSA: analiza completa pe fiecare bursa secundara, in paralel,
    # DUPA ce tot ce tine de bursa activa e salvat - o bursa lenta sau cazuta nu
    # poate afecta planurile, invatarea sau datele bursei active.
    try:
        mods = run_exchange_modules(exchange_cards, exchange_handles, exchange_id, {
            "scope": coingecko_scope, "weights": weights, "hist_tab": _hist_tab,
            "alt_state": alt_state, "calibration": calibration, "agent_model": agent_model,
            "agent_state": agent_state, "closed": closed_for_neighbors, "plan_store": plan_store,
            "now_ts": now_ts, "budget": EXCHANGE_TIME_BUDGET,
            "limit": max(SECONDARY_SCAN_LIMIT, len(CONFIG.get("watchlist") or []))})
    except Exception as _e:
        print(f"[!] modulele per bursa: {_e}")
        mods = {}
    scans.update(mods)
    save_json(EXCHANGE_SCANS_FILE, {"scans": scans, "primary": exchange_id,
                                    "timeframe": CONFIG["timeframe"]})
    print("Ruleaza si generate_dashboard.py ca sa actualizezi docs/index.html")


if __name__ == "__main__":
    main()
